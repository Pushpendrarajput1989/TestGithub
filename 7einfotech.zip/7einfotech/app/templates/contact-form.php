<?php
include('config.php');
$errors = array();
$data = array();
// Getting posted data and decodeing json
$_POST = json_decode(file_get_contents('php://input'), true);
$name = $_POST['inputName'];
$email = $_POST['inputEmail'];
$subject = $_POST['inputSubject'];
$message = $_POST['inputMessage'];



print_r($_POST);
die;

$arr = array(
	'success'=>1,
	'message'=>'Hello test'
);
echo json_encode($arr);

die;

?>
