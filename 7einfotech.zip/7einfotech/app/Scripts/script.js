// Create a module
var myApp = angular.module("myModule",['ngRoute','ngAnimate','angularModalService','ngMessages','uiGmapgoogle-maps','ui.bootstrap']);

myApp.controller("teamController",function($scope,dataFactory){
	$scope.showLoading = true;	
	dataFactory.getData('services/page_details/8').success(function(response){
		$scope.teamDetails = response.data;
		$scope.showLoading = false;	
	});

	dataFactory.getData('services/team_members').success(function(response){
		$scope.teamMembers = response.data;
		$scope.showLoading = false;	
	});

});

myApp.controller("mainController",function($scope,dataFactory){
		$scope.myInterval = 5000;
		$scope.slides = [
		{
			image: 'http://lorempixel.com/400/200/'
		},
		{
			image: 'http://lorempixel.com/400/200/food'
		},
		{
			image: 'http://lorempixel.com/400/200/sports'
		}
		];

		$scope.readMore = function(pageId){
			dataFactory.getData('services/page_details/'+pageId).success(function(response){
				$scope.welcomeDetails = response.data;
			});
		}

		dataFactory.getData('services/page_details/8').success(function(response){
			$scope.welcomeDetails = response.data;
			$scope.showLoading = false;	
		});

		dataFactory.getData('services/page_details/9').success(function(response){
			$scope.skillDetails = response.data;
			$scope.showLoading = false;	
		});
	}
);
myApp.controller("aboutController",function($scope,dataFactory){
		$scope.showLoading = true;	
		dataFactory.getData('services/page_details/4').success(function(response){
			$scope.aboutDetails = response.data;
			$scope.showLoading = false;	
		});

		dataFactory.getData('services/page_details/5').success(function(response){
			$scope.howWeWorkDetails = response.data;
			$scope.showLoading = false;	
		});

		dataFactory.getData('services/page_details/6').success(function(response){
			$scope.missonDetails = response.data;
			$scope.showLoading = false;	
		});

		dataFactory.getData('services/page_details/7').success(function(response){
			$scope.storyDetails = response.data;
			$scope.showLoading = false;	
		});

		dataFactory.getData('services/how_we_work').success(function(response){
			$scope.howWeWorks = response.data;
			$scope.showLoading = false;	
		});

		$scope.readMore = function(pageId){
			dataFactory.getData('services/page_details/'+pageId).success(function(response){
				$scope.welcomeDetails = response.data;
			});
		}

		$scope.myInterval = 3000;
		$scope.slides = [
		{
			image: 'http://lorempixel.com/400/200/'
		},
		{
			image: 'http://lorempixel.com/400/200/food'
		},
		{
			image: 'http://lorempixel.com/400/200/sports'
		}
		];


	}
);

myApp.controller("serviceController",function($scope,dataFactory){
		dataFactory.getData('services/page_details/3').success(function(response){
			$scope.pageDetails = response.data;
			$scope.showLoading = false;	
		});

		$scope.showLoading = true;
		dataFactory.getData('services/get_services').success(function(response){
			$scope.services = response.data;
			$scope.showLoading = false;		
		});
	}
);

myApp.controller("modalController",function($scope,close,dataFactory,$rootScope,ModalService,portfolioId){
		dataFactory.getData('services/portfolio_details/'+portfolioId).success(function(response){
			$scope.projectDetails = response.data.Portfolio;
		});

		$scope.close = function(result) {
	 	  	close(result, 500); // close, but give 500ms for bootstrap to animate
	  	};
	}
);

myApp.controller("contentController",function($scope,close,dataFactory,$rootScope,ModalService,portfolioId){
	alert(portfolioId);
		// dataFactory.getData('services/portfolio_details/'+portfolioId).success(function(response){
		// 	$scope.projectDetails = response.data.Portfolio;
		// });

		// $scope.close = function(result) {
	 // 	  	close(result, 500); // close, but give 500ms for bootstrap to animate
	 //  	};
	}
);

myApp.controller("portfolioController",function($scope,dataFactory,$rootScope,ModalService){
		$scope.showLoading = true;
		dataFactory.getData('services/portfolios').success(function(response){
			$scope.projects = response.data;
			$scope.longNumberLimit = 6;
			$scope.showLoading = false;	
			$scope.selectedIndex = '';		
		});

		dataFactory.getData('services/page_details/1').success(function(response){
			$scope.pageDetails = response.data;
			$scope.showLoading = false;	
		});

		$scope.showProjectPreview = function(id){
			
			ModalService.showModal({
	            templateUrl: 'app/templates/portfolioDetails.html',
	            controller: "modalController",
				  inputs: {
					portfolioId: id
				  }
	        }).then(function(modal) {
	            modal.element.modal();
		      	modal.close.then(function(result) {
		        	$scope.yesNoResult = result ? "You said Yes" : "You said No";
		      	});
	        });
		}

		$scope.filter = function(id){
			$scope.showLoading = true;
			dataFactory.getData('services/portfolio_by_category_id/'+id).success(function(response){
				$scope.projects = response.data;
				$scope.selectedIndex = id;
				$scope.showLoading = false;	
			});
		}
		
		$scope.loadMore = function(){
			$scope.showLoading = true;
			$scope.longNumberLimit = ($scope.longNumberLimit+3);
			$scope.showLoading = false;	
		}

	}
);

myApp.controller("contactController",function($scope,dataFactory,$interval){

		$scope.showLoading = true;
		dataFactory.getData('services/page_details/2').success(function(response){
			$scope.pageDetails = response.data;
			$scope.showLoading = false;	
		});

		$scope.processingIcon = false;
		$scope.formData; //formData is an object holding the name, email, subject, and message
		$scope.submitButtonDisabled = false;
		$scope.submitted = false; //used so that form errors are shown only after the form has been submitted
		$scope.contactSubmit = function() {

			

			$scope.processingIcon = true;
			$scope.submitted = true;
			$scope.submitButtonDisabled = false;
			$scope.showProcessing = true;

			if ($scope.contactForm.$valid) {
				dataFactory.postFormData('services/contact/', $scope.formData).success(function(response){
					$scope.processingIcon = false;
					$scope.resultMessage = response.message;
					$scope.showProcessing = false;	
					$scope.submitButtonDisabled = false;
				});
			}else{
				$scope.processingIcon = false;
				$scope.resultMessage = 'Sorry! Please full fill above validation.';
				$scope.showProcessing = false;	
				$scope.submitButtonDisabled = false;
			}

			return false;
		}


		angular.extend($scope, {
		    map: {
		      	control: {},
		      	center: {
		        	latitude: 45,
		        	longitude: -73
		      	},
		      	options: {
		        	streetViewControl: false,
		        	panControl: false,
		        	maxZoom: 20,
		        	minZoom: 4
		      	},
		      	zoom: 4,
		      	dragging: false,
		      	bounds: {},
		      	markers2: [
			        {
			          	id: 1,
			          	latitude: 46,
			          	longitude: -77,
			          	title: '7einfotech'
			        },
		      	],
		      	dynamicMarkers: [],
		    }
		});
	}
);

myApp.controller("loginController",function($scope,$http){

		$scope.result = 'hidden'
		$scope.resultMessage;
		$scope.formData; //formData is an object holding the name, email, subject, and message
		$scope.submitButtonDisabled = false;
		$scope.submitted = false; //used so that form errors are shown only after the form has been submitted
		$scope.submit = function(contactform) {
			
			$scope.submitted = true;
			$scope.submitButtonDisabled = true;
			if (contactform.$valid) {
				alert($scope.formData.inputEmail);
				$http({
					method  : 'POST',
					url     : 'contact-form.php',
					data    : $.param($scope.formData),  //param method from jQuery
					headers : { 'Content-Type': 'application/x-www-form-urlencoded' }  //set the headers so angular passing info as form data (not request payload)
				}).success(function(data){
					alert(data);
					//return false;
					if (data.success) { //success comes from the return json object
						$scope.submitButtonDisabled = true;
						$scope.resultMessage = data.message;
						$scope.result='bg-success';
					} else {
						$scope.submitButtonDisabled = false;
						$scope.resultMessage = data.message;
						$scope.result='bg-danger';
					}
				});
			} else {
				
				$scope.submitButtonDisabled = false;
				$scope.resultMessage = 'Failed <img src="http://www.chaosm.net/blog/wp-includes/images/smilies/icon_sad.gif" alt=":(" class="wp-smiley">  Please fill out all the fields.';
				$scope.result='bg-danger';
			}
			return false;
		}
	}
);


myApp.config(function($routeProvider) {
    $routeProvider

        // route for the home page
        .when('/home', {
            templateUrl : 'app/templates/home.html',
            activetab : 'home',
            controller  : 'mainController'
        })

        // route for the about page
        .when('/about', {
            templateUrl : 'app/templates/about.html',
            controller  : 'aboutController'
        })

        // route for the contact page
        .when('/contact', {
            templateUrl : 'app/templates/contact.html',
            controller  : 'contactController'
        })

        // route for the contact page
        .when('/service', {
            templateUrl : 'app/templates/service.html',
            controller  : 'serviceController'
        })

        .when('/team', {
            templateUrl : 'app/templates/team.html',
            controller  : 'teamController'
        })

        .when('/details', {
            templateUrl : 'app/templates/details.html',
            controller  : 'contentController'
        })

        // route for the portfolio page
        .when('/portfolio', {
            templateUrl : 'app/templates/portfolio.html',
            controller  : 'portfolioController'
        }).otherwise({redirectTo : '/home'});

}).run(function($rootScope, $location){
	
	$rootScope.rootUrl = 'http://localhost:8080/7einfotech/';
	$rootScope.siteUrl = 'http://localhost:8080/7einfotech/webmaster/';
	
	$rootScope.isLoggedIn = false;
	$rootScope.userDetails = null;
	
 });


