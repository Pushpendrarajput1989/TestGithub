<?php
App::uses('AppController', 'Controller');

class ServicesController extends AppController {
	public $name = 'Services';
	public $helpers = array('Form', 'Html', 'Js');	
	public $uses = array('Portfolio','Content','Contact','Service','HowWeWork','Team');
	
	function beforeFilter(){
		parent::beforeFilter();
		$this->Auth->allow(array('portfolios','portfolio_details','page_details','portfolio_by_category_id','contact','get_services','how_we_work','team_members'));	
		header('Access-Control-Allow-Origin: *'); 
		header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Access-Control-Allow-Origin'); 
		header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE');
	}
	

	public function portfolios() {
		$data = $this->Portfolio->find('all',array('limit'=>9,'fields'=>array('id','title','link','big_img')));
	
		foreach ($data as $key => $value) {
			$projects[$key]= $value['Portfolio'];
		}
		$returnData = array('status' => true, 'data' => $projects);
		echo json_encode($returnData);
		die;		
	}

	public function portfolio_details($id=''){
		$data = $this->Portfolio->findById($id,array('id','title','link','big_img','short_description'));
		$returnData = array('status' => true, 'data' => $data);
		echo json_encode($returnData);
		die;		
	}

	public function page_details($id=''){
		$data = $this->Content->findByPageId($id,array('page_id','page_title','page_content','page_short_content'));
		$returnData = array('status' => true, 'data' => $data['Content']);
		echo json_encode($returnData);
		die;
	}

	public function portfolio_by_category_id($id=''){
		if($id!=''){
			$data = $this->Portfolio->find('all',array('conditions'=>array('category_id'=>$id),'order'=>'id ASC','limit'=>9,'fields'=>array('id','title','link','big_img')));
		}else{
			$data = $this->Portfolio->find('all',array('order'=>'id ASC','limit'=>9,'fields'=>array('id','title','link','big_img')));
		}
	
		foreach ($data as $key => $value) {
			$projects[$key]= $value['Portfolio'];
		}
		$returnData = array('status' => true, 'data' => $projects);
		echo json_encode($returnData);
		die;	
	}

	public function contact(){
		$data = json_decode(json_encode($this->request->input('json_decode')),true);

		if (!empty($data)) {
			$this->Contact->create();
			
			$this->request->data['Contact']['name'] = $data['name'];
			$this->request->data['Contact']['email'] = $data['email'];
			$this->request->data['Contact']['subject'] = $data['subject'];
			$this->request->data['Contact']['comment'] = $data['comment'];
			if($this->Contact->save($this->request->data)){
				$returnData = array('status' => true, 'message' =>'Thank you! your request submitted successfully, we will contact you soon.');
				echo json_encode($returnData);
			}else{
				$returnData = array('status' => true, 'message' =>'Sorry! your request not submitted, please try again.');
				echo json_encode($returnData);
			}
		}
		die;
	}

	public function get_services(){
		$data = $this->Service->find('all',array('limit'=>9,'fields'=>array('id','title','description','icon')));
	
		foreach ($data as $key => $value) {
			$services[$key]= $value['Service'];
		}
		$returnData = array('status' => true, 'data' => $services);
		echo json_encode($returnData);
		die;		
	}

	public function how_we_work(){
		$data = $this->HowWeWork->find('all',array('limit'=>9,'fields'=>array('id','title','description','img','short_description')));
	
		foreach ($data as $key => $value) {
			$services[$key]= $value['HowWeWork'];
		}
		$returnData = array('status' => true, 'data' => $services);
		echo json_encode($returnData);
		die;	
	}

	public function team_members() {
		$data = $this->Team->find('all',array('limit'=>12,'fields'=>array('id','name','position','image','description')));
	
		foreach ($data as $key => $value) {
			$projects[$key]= $value['Team'];
		}
		$returnData = array('status' => true, 'data' => $projects);
		echo json_encode($returnData);
		die;		
	}
}
