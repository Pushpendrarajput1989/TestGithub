<?php
class HomeController extends AppController {

	public $name = 'Home';
	public $helpers = array('Form', 'Html', 'Js');
	public $paginate = array('limit' => 10);	
	public $components = array('RequestHandler');
	public $uses=array('Content','Post');	
	public $scaffold;
	
	function beforeFilter(){
		parent::beforeFilter();
		$this->Auth->allow(array('index','about'));		
	}	
	
	function admin_index() {
		$this->set('title_for_layout','Dashboard');
	}
	
	function index() {
	
		// $this->layout = 'home.html';
		$posts = $this->Post->find('all');
        $this->set(array(
            'posts' => $posts,
            '_serialize' => array('posts')
        ));
		// die;
		//die;	
		// $posts = $this->Content->find('all');
  //       $this->set(array(
  //           'posts' => $posts,
  //           '_serialize' => array('posts')
  //       ));
	}

	function about() {
		echo 'dfdfdf';
		die;
		// die;
		//die;	
		// $posts = $this->Content->find('all');
  //       $this->set(array(
  //           'posts' => $posts,
  //           '_serialize' => array('posts')
  //       ));
	}
	
}
