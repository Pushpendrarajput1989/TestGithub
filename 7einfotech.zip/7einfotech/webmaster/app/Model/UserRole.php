<?php
class UserRole extends AppModel {
	 public $name = 'UserRole';
	 public $primaryKey = 'user_role_id';
	
}
