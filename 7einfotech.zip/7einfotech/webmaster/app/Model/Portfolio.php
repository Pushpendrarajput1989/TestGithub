<?php
class Portfolio extends AppModel {
	public $name = 'Portfolio';
			
}
