<?php

class Country extends AppModel {
	
	public $primaryKey='country_id';
	
}
