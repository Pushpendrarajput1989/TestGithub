<?php
App::uses('AppModel', 'Model');

class HowWeWork extends AppModel {

}
