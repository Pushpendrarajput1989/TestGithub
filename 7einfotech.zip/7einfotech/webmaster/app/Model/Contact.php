<?php
App::uses('AppModel', 'Model');

class Contact extends AppModel {

}
