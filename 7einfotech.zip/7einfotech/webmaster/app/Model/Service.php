<?php
App::uses('AppModel', 'Model');

class Service extends AppModel {

}
