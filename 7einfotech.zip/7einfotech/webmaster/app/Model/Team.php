<?php
App::uses('AppModel', 'Model');

class Team extends AppModel {

}
