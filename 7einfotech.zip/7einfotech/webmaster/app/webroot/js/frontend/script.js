// Create a module
var myApp = angular.module("myModule",['ngRoute']);


// myApp.factory('UserService', UserService);

// UserService.$inject = ['$http'];
// function UserService($http) {
//     var service = {};

//     service.GetAll = GetAll;
//     service.GetById = GetById;
//     service.GetByUsername = GetByUsername;
//     service.Create = Create;
//     service.Update = Update;
//     service.Delete = Delete;

//     return service;

//     function GetAll() {
//         return $http.get('/api/users').then(handleSuccess, handleError('Error getting all users'));
//     }

//     function GetById(id) {
//         return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
//     }

//     function GetByUsername(username) {
//         return $http.get('/api/users/' + username).then(handleSuccess, handleError('Error getting user by username'));
//     }

//     function Create(user) {
//         return $http.post('/api/users', user).then(handleSuccess, handleError('Error creating user'));
//     }

//     function Update(user) {
//         return $http.put('/api/users/' + user.id, user).then(handleSuccess, handleError('Error updating user'));
//     }

//     function Delete(id) {
//         return $http.delete('/api/users/' + id).then(handleSuccess, handleError('Error deleting user'));
//     }

//     // private functions

//     function handleSuccess(res) {
//         return res.data;
//     }

//     function handleError(error) {
//         return function () {
//             return { success: false, message: error };
//         };
//     }
// }

myApp.controller("myController",
	function($scope, $http, $log){
		$http.get('')
			.then(function(response){
				$scope.emp = response.data;
				$log.info(response);
			});

		var employees = [
		{firstName:"Puspendra",	lastName:"Rajput", gender:"male"},
		{firstName:"Kapil",	lastName:"Rai", gender:"male"},
		{firstName:"Rani",	lastName:"Gupta", gender:"female"}
		];
		
		var countries = [
		{name:"India",cities:[{name:"bhopal"},{name:"gwalior"},{name:"delhi"}]},
		{name:"UK",cities:[{name:"London"},{name:"manchester"},{name:"birmingham"}]},
		];
		
		var employee = {
			firstName:"Puspendra",
			lastName:"Rajput",
			gender:"male"
		};
		
		var country ={
			name:"USA",
			capital:"Washington, D.C.",
			flag:"Images/AngularJS.png"
		};
		$scope.countries = countries;
		$scope.employees = employees;
		$scope.employee = employee;
		$scope.country = country;
		$scope.message = "AngularJs Tutorial";
	}


);

myApp.controller("mainController",function($scope,$http,hexafy,UserService){
		$scope.hex = hexafy.myFunc(155);
		$scope.message = "Hello User";
		$scope.mm = UserService.GetAll();
	}
);
myApp.controller("aboutController",function($scope){
		$scope.message = "Hello User";
	}
);

myApp.controller("portfolioController",function($scope,PortfolioService){
		$scope.message = "portfolio page";
		$scope.portfolios = PortfolioService.GetAll();
	}
);

myApp.controller("contactController",function($scope,$http){

		$scope.result = 'hidden'
		$scope.resultMessage;
		$scope.formData; //formData is an object holding the name, email, subject, and message
		$scope.submitButtonDisabled = false;
		$scope.submitted = false; //used so that form errors are shown only after the form has been submitted
		$scope.submit = function(contactform) {
			
			$scope.submitted = true;
			$scope.submitButtonDisabled = true;
			if (contactform.$valid) {
				//alert($scope.formData.inputEmail);
				$http.post('pages/contact-form.php', $scope.formData).success(function(data) { 
					//alert(data);
					if (data.success) { //success comes from the return json object
						$scope.submitButtonDisabled = true;
						$scope.resultMessage = 'success';
						$scope.result='bg-success';
					} else {
						$scope.submitButtonDisabled = false;
						$scope.resultMessage = 'failed';
						$scope.result='bg-danger';
					}
					    if (data.errors) {
			              // Showing errors.
			              $scope.errorinputName = data.errors.name;
			              $scope.errorinputEmail = data.errors.inputEmail;
			              $scope.errorEmail = data.errors.email;
			            } 

				}); 
				// $http({
				// 	method  : 'POST',
				// 	url     : 'contact-form.php',
				// 	data    : $.param($scope.formData),  //param method from jQuery
				// 	headers : { 'Content-Type': 'application/x-www-form-urlencoded' }  //set the headers so angular passing info as form data (not request payload)
				// }).success(function(data){
				// 	alert(data);
				// 	//return false;
				// 	if (data.success) { //success comes from the return json object
				// 		$scope.submitButtonDisabled = true;
				// 		$scope.resultMessage = data.message;
				// 		$scope.result='bg-success';
				// 	} else {
				// 		$scope.submitButtonDisabled = false;
				// 		$scope.resultMessage = data.message;
				// 		$scope.result='bg-danger';
				// 	}
				// });
			} else {
				
				$scope.submitButtonDisabled = false;
				$scope.resultMessage = 'Failed <img src="http://www.chaosm.net/blog/wp-includes/images/smilies/icon_sad.gif" alt=":(" class="wp-smiley">  Please fill out all the fields.';
				$scope.result='bg-danger';
			}
			return false;
		}
	}
);

myApp.controller("loginController",function($scope,$http){

		$scope.result = 'hidden'
		$scope.resultMessage;
		$scope.formData; //formData is an object holding the name, email, subject, and message
		$scope.submitButtonDisabled = false;
		$scope.submitted = false; //used so that form errors are shown only after the form has been submitted
		$scope.submit = function(contactform) {
			
			$scope.submitted = true;
			$scope.submitButtonDisabled = true;
			if (contactform.$valid) {
				alert($scope.formData.inputEmail);
				$http({
					method  : 'POST',
					url     : 'contact-form.php',
					data    : $.param($scope.formData),  //param method from jQuery
					headers : { 'Content-Type': 'application/x-www-form-urlencoded' }  //set the headers so angular passing info as form data (not request payload)
				}).success(function(data){
					alert(data);
					//return false;
					if (data.success) { //success comes from the return json object
						$scope.submitButtonDisabled = true;
						$scope.resultMessage = data.message;
						$scope.result='bg-success';
					} else {
						$scope.submitButtonDisabled = false;
						$scope.resultMessage = data.message;
						$scope.result='bg-danger';
					}
				});
			} else {
				
				$scope.submitButtonDisabled = false;
				$scope.resultMessage = 'Failed <img src="http://www.chaosm.net/blog/wp-includes/images/smilies/icon_sad.gif" alt=":(" class="wp-smiley">  Please fill out all the fields.';
				$scope.result='bg-danger';
			}
			return false;
		}
	}
);


myApp.config(function($routeProvider) {
    $routeProvider

        // route for the home page
        // .when('/', {
        //     templateUrl : 'home/home.html',
        //     activetab : 'home',
        //     controller  : 'mainController'
        // })

        // route for the about page
        .when('/about', {
            templateUrl : 'home/about',
            controller  : 'aboutController'
        })

        // route for the contact page
        .when('/contact', {
            templateUrl : 'pages/contact.html',
            controller  : 'contactController'
        })
        // route for the portfolio page
        .when('/portfolio', {
            templateUrl : 'pages/portfolio.html',
            controller  : 'portfolioController'
        });

});


myApp.service('hexafy', function() {
    this.myFunc = function (x) {
        return x.toString(16);
    }
});


