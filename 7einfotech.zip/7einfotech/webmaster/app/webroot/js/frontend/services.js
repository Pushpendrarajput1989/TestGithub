(function () {
	var as = angular.module('myApp.service', []);
	var as = angular.module('myApp.service1', []);

	myApp.factory('UserService', UserService);

	UserService.$inject = ['$http'];
	function UserService($http) {
    
        var service = {};

	    service.GetAll = GetAll;
	    service.GetById = GetById;

	    return service;

	    function GetAll() {
	        return $http.get('/api/users').then(handleSuccess, handleError('Error getting all users'));
	    }

	    function GetById(id) {
	        return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
	    }

	    // private functions

	    function handleSuccess(res) {
	        return res.data;
	    }

	    function handleError(error) {
	        return function () {
	            return { success: false, message: error };
	        };
	    }
    }

    myApp.factory('PortfolioService', PortfolioService);

	PortfolioService.$inject = ['$http'];
	function PortfolioService($http) {
    
        var service1 = {};

	    service1.GetAll = GetAll;
	    service1.GetById = GetById;

	    return service1;

	    function GetAll() {
	        return $http.get('/api/usersddddd').then(handleSuccess, handleError('Error getting all users'));
	    }

	    function GetById(id) {
	        return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
	    }

	    // private functions

	    function handleSuccess(res) {
	        return res.data;
	    }

	    function handleError(error) {
	        return function () {
	            return { success: false, message: error };
	        };
	    }
    }

}());
