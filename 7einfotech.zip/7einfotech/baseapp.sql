-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2016 at 10:56 PM
-- Server version: 5.5.36
-- PHP Version: 5.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `baseapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `subject` varchar(256) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `comment`) VALUES
(1, 'Pushpendra Rajput', 'rajput.pushpendra61@gmail.com', 'Test', 'Test message'),
(2, 'dfdsfsddf', 'dfsfdsfdsf@gmail.com', 'dfssdfffsd', 'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd'),
(3, 'dfdsfsddf', 'dfsfdsfdsf@gmail.com', 'dfssdfffsd', 'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd'),
(4, 'dfdsfsddf', 'dfsfdsfdsf@gmail.com', 'dfssdfffsd', 'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd'),
(5, 'dfdsfsddf', 'dfsfdsfdsf@gmail.com', 'dfssdfffsd', 'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd');

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `page_slug` varchar(255) NOT NULL,
  `page_sub_title` varchar(255) DEFAULT NULL,
  `page_short_content` text,
  `page_content` text,
  `status` enum('Publish','Draft','Trash') NOT NULL DEFAULT 'Publish',
  `page_added_date` datetime DEFAULT NULL,
  `page_modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`page_id`, `page_title`, `page_slug`, `page_sub_title`, `page_short_content`, `page_content`, `status`, `page_added_date`, `page_modified_date`) VALUES
(1, 'Our Projects', 'our_projects', NULL, NULL, 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit ametLorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet', 'Publish', NULL, NULL),
(2, 'Contact Us', 'contact_us', NULL, NULL, 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit ametLorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet', 'Publish', NULL, NULL),
(3, 'Our Sevices', 'our_services', NULL, 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\nminim veniam quis notru exercit ation Lorem ipsum dolor sit ametLorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet', 'Publish', NULL, NULL),
(4, 'About Us', 'about_us', NULL, NULL, 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit ametLorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet', 'Publish', NULL, NULL),
(5, 'How we work', 'how_we_work', NULL, NULL, 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit ametLorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet', 'Publish', NULL, NULL),
(6, 'Our Mission', 'our_mission', NULL, 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit ametLorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet', 'Publish', NULL, NULL),
(7, 'Our Story', 'our_story', NULL, NULL, 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit ametLorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet', 'Publish', NULL, NULL),
(8, 'Welcome to Screen creative Template', 'Welcome_to_Screen_creative_Template', NULL, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit! Aperiam omnis, cupiditate laudantium velit nostrum, exercitationem accusamus, possimus soluta illo.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit! Aperiam omnis, cupiditate laudantium velit nostrum, exercitationem accusamus, possimus soluta illo.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit! Aperiam omnis, cupiditate laudantium velit nostrum, exercitationem accusamus, possimus soluta illo.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit.', 'Publish', NULL, NULL),
(9, 'Our Skills', 'our_skills', NULL, 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet.', 'Publish', NULL, NULL),
(10, '', 'Our experts', 'our_expert', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim\r\nminim veniam quis notru exercit ation Lorem ipsum dolor sit amet.', 'Publish', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `country_id` int(5) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(255) NOT NULL,
  `country_code` varchar(50) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=267 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`country_id`, `country_name`, `country_code`) VALUES
(1, 'Andorra', 'AD'),
(2, 'United Arab Emirates', 'AE'),
(3, 'Afghanistan', 'AF'),
(4, 'Antigua and Barbuda', 'AG'),
(5, 'Anguilla', 'AI'),
(6, 'Albania', 'AL'),
(7, 'Armenia', 'AM'),
(8, 'Netherlands Antilles', 'AN'),
(9, 'Angola', 'AO'),
(10, 'Antarctica', 'AQ'),
(11, 'Argentina', 'AR'),
(12, 'American Samoa', 'AS'),
(13, 'Austria', 'AT'),
(14, 'Australia', 'AU'),
(15, 'Aruba', 'AW'),
(16, 'Aland Islands', 'AX'),
(17, 'Azerbaijan', 'AZ'),
(18, 'Bosnia and Herzegovina', 'BA'),
(19, 'Barbados', 'BB'),
(20, 'Bangladesh', 'BD'),
(21, 'Belgium', 'BE'),
(22, 'Burkina Faso', 'BF'),
(23, 'Bulgaria', 'BG'),
(24, 'Bahrain', 'BH'),
(25, 'Burundi', 'BI'),
(26, 'Benin', 'BJ'),
(27, 'Saint Barthelemy', 'BL'),
(28, 'Bermuda', 'BM'),
(29, 'Brunei', 'BN'),
(30, 'Bolivia', 'BO'),
(31, 'British Antarctic Territory', 'BQ'),
(32, 'Brazil', 'BR'),
(33, 'Bahamas', 'BS'),
(34, 'Bhutan', 'BT'),
(35, 'Bouvet Island', 'BV'),
(36, 'Botswana', 'BW'),
(37, 'Belarus', 'BY'),
(38, 'Belize', 'BZ'),
(39, 'Canada', 'CA'),
(40, 'Cocos [Keeling] Islands', 'CC'),
(41, 'Congo - Kinshasa', 'CD'),
(42, 'Central African Republic', 'CF'),
(43, 'Congo - Brazzaville', 'CG'),
(44, 'Switzerland', 'CH'),
(45, 'Cote dIvoire', 'CI'),
(46, 'Cook Islands', 'CK'),
(47, 'Chile', 'CL'),
(48, 'Cameroon', 'CM'),
(49, 'China', 'CN'),
(50, 'Colombia', 'CO'),
(51, 'Costa Rica', 'CR'),
(52, 'Serbia and Montenegro', 'CS'),
(53, 'Canton and Enderbury Islands', 'CT'),
(54, 'Cuba', 'CU'),
(55, 'Cape Verde', 'CV'),
(56, 'Christmas Island', 'CX'),
(57, 'Cyprus', 'CY'),
(58, 'Czech Republic', 'CZ'),
(59, 'East Germany', 'DD'),
(60, 'Germany', 'DE'),
(61, 'Djibouti', 'DJ'),
(62, 'Denmark', 'DK'),
(63, 'Dominica', 'DM'),
(64, 'Dominican Republic', 'DO'),
(65, 'Algeria', 'DZ'),
(66, 'Ecuador', 'EC'),
(67, 'Estonia', 'EE'),
(68, 'Egypt', 'EG'),
(69, 'Western Sahara', 'EH'),
(70, 'Eritrea', 'ER'),
(71, 'Spain', 'ES'),
(72, 'Ethiopia', 'ET'),
(73, 'Finland', 'FI'),
(74, 'Fiji', 'FJ'),
(75, 'Falkland Islands', 'FK'),
(76, 'Micronesia', 'FM'),
(77, 'Faroe Islands', 'FO'),
(78, 'French Southern and Antarctic Territories', 'FQ'),
(79, 'France', 'FR'),
(80, 'Metropolitan France', 'FX'),
(81, 'Gabon', 'GA'),
(82, 'United Kingdom', 'GB'),
(83, 'Grenada', 'GD'),
(84, 'Georgia', 'GE'),
(85, 'French Guiana', 'GF'),
(86, 'Guernsey', 'GG'),
(87, 'Ghana', 'GH'),
(88, 'Gibraltar', 'GI'),
(89, 'Greenland', 'GL'),
(90, 'Gambia', 'GM'),
(91, 'Guinea', 'GN'),
(92, 'Guadeloupe', 'GP'),
(93, 'Equatorial Guinea', 'GQ'),
(94, 'Greece', 'GR'),
(95, 'South Georgia and the South Sandwich Islands', 'GS'),
(96, 'Guatemala', 'GT'),
(97, 'Guam', 'GU'),
(98, 'Guinea-Bissau', 'GW'),
(99, 'Guyana', 'GY'),
(100, 'Hong Kong SAR China', 'HK'),
(101, 'Heard Island and McDonald Islands', 'HM'),
(102, 'Honduras', 'HN'),
(103, 'Croatia', 'HR'),
(104, 'Haiti', 'HT'),
(105, 'Hungary', 'HU'),
(106, 'Indonesia', 'ID'),
(107, 'Ireland', 'IE'),
(108, 'Israel', 'IL'),
(109, 'Isle of Man', 'IM'),
(110, 'India', 'IN'),
(111, 'British Indian Ocean Territory', 'IO'),
(112, 'Iraq', 'IQ'),
(113, 'Iran', 'IR'),
(114, 'Iceland', 'IS'),
(115, 'Italy', 'IT'),
(116, 'Jersey', 'JE'),
(117, 'Jamaica', 'JM'),
(118, 'Jordan', 'JO'),
(119, 'Japan', 'JP'),
(120, 'Johnston Island', 'JT'),
(121, 'Kenya', 'KE'),
(122, 'Kyrgyzstan', 'KG'),
(123, 'Cambodia', 'KH'),
(124, 'Kiribati', 'KI'),
(125, 'Comoros', 'KM'),
(126, 'Saint Kitts and Nevis', 'KN'),
(127, 'North Korea', 'KP'),
(128, 'South Korea', 'KR'),
(129, 'Kuwait', 'KW'),
(130, 'Cayman Islands', 'KY'),
(131, 'Kazakhstan', 'KZ'),
(132, 'Laos', 'LA'),
(133, 'Lebanon', 'LB'),
(134, 'Saint Lucia', 'LC'),
(135, 'Liechtenstein', 'LI'),
(136, 'Sri Lanka', 'LK'),
(137, 'Liberia', 'LR'),
(138, 'Lesotho', 'LS'),
(139, 'Lithuania', 'LT'),
(140, 'Luxembourg', 'LU'),
(141, 'Latvia', 'LV'),
(142, 'Libya', 'LY'),
(143, 'Morocco', 'MA'),
(144, 'Monaco', 'MC'),
(145, 'Moldova', 'MD'),
(146, 'Montenegro', 'ME'),
(147, 'Saint Martin', 'MF'),
(148, 'Madagascar', 'MG'),
(149, 'Marshall Islands', 'MH'),
(150, 'Midway Islands', 'MI'),
(151, 'Macedonia', 'MK'),
(152, 'Mali', 'ML'),
(153, 'Myanmar [Burma]', 'MM'),
(154, 'Mongolia', 'MN'),
(155, 'Macau SAR China', 'MO'),
(156, 'Northern Mariana Islands', 'MP'),
(157, 'Martinique', 'MQ'),
(158, 'Mauritania', 'MR'),
(159, 'Montserrat', 'MS'),
(160, 'Malta', 'MT'),
(161, 'Mauritius', 'MU'),
(162, 'Maldives', 'MV'),
(163, 'Malawi', 'MW'),
(164, 'Mexico', 'MX'),
(165, 'Malaysia', 'MY'),
(166, 'Mozambique', 'MZ'),
(167, 'Namibia', 'NA'),
(168, 'New Caledonia', 'NC'),
(169, 'Niger', 'NE'),
(170, 'Norfolk Island', 'NF'),
(171, 'Nigeria', 'NG'),
(172, 'Nicaragua', 'NI'),
(173, 'Netherlands', 'NL'),
(174, 'Norway', 'NO'),
(175, 'Nepal', 'NP'),
(176, 'Dronning Maud Land', 'NQ'),
(177, 'Nauru', 'NR'),
(178, 'Neutral Zone', 'NT'),
(179, 'Niue', 'NU'),
(180, 'New Zealand', 'NZ'),
(181, 'Oman', 'OM'),
(182, 'Panama', 'PA'),
(183, 'Pacific Islands Trust Territory', 'PC'),
(184, 'Peru', 'PE'),
(185, 'French Polynesia', 'PF'),
(186, 'Papua New Guinea', 'PG'),
(187, 'Philippines', 'PH'),
(188, 'Pakistan', 'PK'),
(189, 'Poland', 'PL'),
(190, 'Saint Pierre and Miquelon', 'PM'),
(191, 'Pitcairn Islands', 'PN'),
(192, 'Puerto Rico', 'PR'),
(193, 'Palestinian Territories', 'PS'),
(194, 'Portugal', 'PT'),
(195, 'U.S. Miscellaneous Pacific Islands', 'PU'),
(196, 'Palau', 'PW'),
(197, 'Paraguay', 'PY'),
(198, 'Panama Canal Zone', 'PZ'),
(199, 'Qatar', 'QA'),
(200, 'Reunion', 'RE'),
(201, 'Romania', 'RO'),
(202, 'Serbia', 'RS'),
(203, 'Russia', 'RU'),
(204, 'Rwanda', 'RW'),
(205, 'Saudi Arabia', 'SA'),
(206, 'Solomon Islands', 'SB'),
(207, 'Seychelles', 'SC'),
(208, 'Sudan', 'SD'),
(209, 'Sweden', 'SE'),
(210, 'Singapore', 'SG'),
(211, 'Saint Helena', 'SH'),
(212, 'Slovenia', 'SI'),
(213, 'Svalbard and Jan Mayen', 'SJ'),
(214, 'Slovakia', 'SK'),
(215, 'Sierra Leone', 'SL'),
(216, 'San Marino', 'SM'),
(217, 'Senegal', 'SN'),
(218, 'Somalia', 'SO'),
(219, 'Suriname', 'SR'),
(220, 'Sao Tome and Principe', 'ST'),
(221, 'Union of Soviet Socialist Republics', 'SU'),
(222, 'El Salvador', 'SV'),
(223, 'Syria', 'SY'),
(224, 'Swaziland', 'SZ'),
(225, 'Turks and Caicos Islands', 'TC'),
(226, 'Chad', 'TD'),
(227, 'French Southern Territories', 'TF'),
(228, 'Togo', 'TG'),
(229, 'Thailand', 'TH'),
(230, 'Tajikistan', 'TJ'),
(231, 'Tokelau', 'TK'),
(232, 'Timor-Leste', 'TL'),
(233, 'Turkmenistan', 'TM'),
(234, 'Tunisia', 'TN'),
(235, 'Tonga', 'TO'),
(236, 'Turkey', 'TR'),
(237, 'Trinidad and Tobago', 'TT'),
(238, 'Tuvalu', 'TV'),
(239, 'Taiwan', 'TW'),
(240, 'Tanzania', 'TZ'),
(241, 'Ukraine', 'UA'),
(242, 'Uganda', 'UG'),
(243, 'U.S. Minor Outlying Islands', 'UM'),
(244, 'United States', 'US'),
(245, 'Uruguay', 'UY'),
(246, 'Uzbekistan', 'UZ'),
(247, 'Vatican City', 'VA'),
(248, 'Saint Vincent and the Grenadines', 'VC'),
(249, 'North Vietnam', 'VD'),
(250, 'Venezuela', 'VE'),
(251, 'British Virgin Islands', 'VG'),
(252, 'U.S. Virgin Islands', 'VI'),
(253, 'Vietnam', 'VN'),
(254, 'Vanuatu', 'VU'),
(255, 'Wallis and Futuna', 'WF'),
(256, 'Wake Island', 'WK'),
(257, 'Samoa', 'WS'),
(258, 'People''s Democratic Republic of Yemen', 'YD'),
(259, 'Yemen', 'YE'),
(260, 'Mayotte', 'YT'),
(261, 'South Africa', 'ZA'),
(262, 'Zambia', 'ZM'),
(263, 'Zimbabwe', 'ZW'),
(264, 'Unknown or Invalid Region', 'ZZ'),
(265, 'West Indies', 'AI'),
(266, 'England', 'UK');

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE IF NOT EXISTS `email_templates` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(255) DEFAULT NULL,
  `template_key` varchar(255) NOT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `from_email` varchar(255) DEFAULT NULL,
  `email_subject` varchar(500) DEFAULT NULL,
  `email_body` text NOT NULL,
  `template_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `template_added_date` datetime DEFAULT NULL,
  `template_modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`template_id`, `template_name`, `template_key`, `from_name`, `from_email`, `email_subject`, `email_body`, `template_status`, `template_added_date`, `template_modified_date`) VALUES
(1, 'forgot_password_email', 'forgot_password_email', 'Pksingh', 'pappu.singh@i-webservices.com', 'Forgot password', 'Dear {name},\r\n\r\nYour password has been reset and new password is: {password}\r\n\r\nThanks\r\nABC Team', 'Active', '2013-04-23 17:18:19', '2014-01-15 15:03:02');

-- --------------------------------------------------------

--
-- Table structure for table `how_we_works`
--

CREATE TABLE IF NOT EXISTS `how_we_works` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `short_description` text,
  `description` text NOT NULL,
  `img` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `how_we_works`
--

INSERT INTO `how_we_works` (`id`, `title`, `short_description`, `description`, `img`) VALUES
(1, 'Planing', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim elitsed eiusmod tempor enim', 'As compare to 7einfotech other company loyalty programs are not very effective at initiating loyalty but that on the other hand, improvements in customer experience are highly correlated to loyalty and revenue.\n', ''),
(2, 'Designing', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim elitsed eiusmod tempor enim\n', 'Design of websites towards digital marketing efforts has become the norm now and who better than us, 7einfotech to provide you with the best of the website solutions! Backed by a team of adroit professionals, we, at 7einfotech know how to develop and optimize your website to enable you to capture the maximum eyeballs as well as retain them. We take care of your Business.', ''),
(3, 'Development', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim elitsed eiusmod tempor enim', 'Design of websites towards digital marketing efforts has become the norm now and who better than us, 7einfotech to provide you with the best of the website solutions! Backed by a team of adroit professionals, we, at 7einfotech know how to develop and optimize your website to enable you to capture the maximum eyeballs as well as retain them. We take care of your Business.', '');

-- --------------------------------------------------------

--
-- Table structure for table `portfolios`
--

CREATE TABLE IF NOT EXISTS `portfolios` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `link` varchar(256) NOT NULL,
  `logo` varchar(256) DEFAULT NULL,
  `short_description` varchar(256) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `small_img` varchar(256) NOT NULL,
  `big_img` varchar(256) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `show_home` tinyint(2) NOT NULL DEFAULT '0',
  `added_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=140 ;

--
-- Dumping data for table `portfolios`
--

INSERT INTO `portfolios` (`id`, `category_id`, `title`, `link`, `logo`, `short_description`, `description`, `small_img`, `big_img`, `status`, `show_home`, `added_on`, `updated_on`) VALUES
(1, 2, 'Callmum', 'http://callmum.com', '04f077ff5bf0db47ad83abdd6c107e6c.png', 'This is our very own London Groove app with details and booking information for our club nights every weekend.\r\nIf you’re having a birthday party, hen party or just a night out with friends we can arrange a guestlist and area for you at any of our club n', '<p>                 </p><p>This is our very own London Groove app with details and booking information for our club nights every weekend.</p><p>                 </p><p>If you’re having a birthday party, hen party or just a  night out with friends we can ar', '7530d425b2c59ced6607d6a702a8a2b3.jpg', 'p-1.jpg', 1, 1, '2016-04-19 15:05:48', '2016-05-18 01:37:08'),
(2, 8, '3csouterwear', 'https://3csouterwear.com', '', '3csouterwear', '<p>3csouterwear</p>', '6ed47a8a1003a63a0bc3577757437355.jpg', 'p-2.jpg', 1, 0, '2016-05-19 06:36:30', '0000-00-00 00:00:00'),
(3, 4, 'BBR GRAPHIC SALES LIMITED BUSINESS', 'https://play.google.com/store/apps/details?id=com.infoicon.bbrgraphics', '', 'Heidelberg, KBA, Roland, Komori, Mitsubishi, Bobst, Muller Martini, Printing, Used printing equipment, 2nd hand printing machinery, printing machinery, printing engineering, printers engineers, large format, used printing dealers,', '<p>Heidelberg, KBA, Roland, Komori, Mitsubishi, Bobst, Muller Martini, Printing, Used printing equipment, 2nd hand printing machinery, printing machinery, printing engineering, printers engineers, large format, used printing dealers,</p>', '', 'p-3.jpg', 1, 0, '2016-05-16 17:21:31', '0000-00-00 00:00:00'),
(4, 4, 'POOLDESIGNESTIMATOR', 'https://play.google.com/store/apps/details?id=com.infoicontechnologies.hohnepools', '', 'The Pooldesignestimator app will provide homeowners, at their convenience, a written proposal with estimate for the inground pool they choose. The complete professional proposal is delivered to them in as little as 10 seconds.', '<p>The Pooldesignestimator app will provide homeowners, at their convenience, a written proposal with estimate for the inground pool they choose. The complete professional proposal is delivered to them in as little as 10 seconds.</p>', '', 'p-4.jpg', 1, 0, '2016-05-16 17:22:46', '0000-00-00 00:00:00'),
(5, 4, 'BECOME A JEDI', 'https://play.google.com/store/apps/details?id=com.app.becomejd', '', 'The purpose of this Application is to take you on a journey. A journey that gives you an understanding of the way of the Jedi. The concepts outlined in this Application may be considered extraordinary. They are certainly not consistent with mainstream view', '<p>The purpose of this Application is to take you on a journey. A journey that gives you an understanding of the way of the Jedi. The concepts outlined in this Application may be considered extraordinary. They are certainly not consistent with mainstream v', '', 'p-5.jpg', 1, 0, '2016-05-16 17:24:06', '0000-00-00 00:00:00'),
(6, 4, 'SUDOKU', 'https://play.google.com/store/apps/details?id=com.Infoicon.Sudoku', '', 'You''ve seen Sudoku in the newspaper, and now you can play the popular logic puzzles on your Android phone. Sudoku creates the crossword-like logic puzzles that exercise your brain without trivia, spelling, or ambiguous crossword clues.', '<p>You''ve seen Sudoku in the newspaper, and now you can play the popular logic puzzles on your Android phone. Sudoku creates the crossword-like logic puzzles that exercise your brain without trivia, spelling, or ambiguous crossword clues.</p>', '', 'p-6.jpg', 1, 0, '2016-05-16 17:25:40', '0000-00-00 00:00:00'),
(7, 4, 'NORMAL TO SILENT', 'hhttps://play.google.com/store/apps/details?id=com.Infoicon.Silent', '', 'Functionality of Application: whenever you turn your phone face-down, it will turn all the sound completely off. That way you can just flip your phone over and get back to whatever you were doing.', '<p>Functionality of Application: whenever you turn your phone face-down, it will turn all the sound completely off. That way you can just flip your phone over and get back to whatever you were doing.</p>', '', 'p-7.jpg', 1, 0, '2016-05-16 17:26:41', '0000-00-00 00:00:00'),
(8, 4, 'RANK TRACKER', 'https://play.google.com/store/apps/details?id=com.Infoicon.Rank.Tracker', '', 'This application is strictly official for Infoicon Technologies (P) Ltd. employees.', '<p>This application is strictly official for Infoicon Technologies (P) Ltd. employees.</p>', '', 'p-8.jpg', 1, 0, '2016-05-16 17:27:50', '0000-00-00 00:00:00'),
(9, 4, 'CPU HARDWARE AND SYSTEM INFO', 'https://play.google.com/store/apps/details?id=com.ssaurel.cpuhardwareinfos', '', 'CPU Hardware and System Info gives you all the information about hardware and system of your device (smartphone or tablet) inside an elegant Material Design interface.', '<p>CPU Hardware and System Info gives you all the information about hardware and system of your device (smartphone or tablet) inside an elegant Material Design interface.</p>', '', 'p-9.jpg', 1, 0, '2016-05-16 17:29:44', '0000-00-00 00:00:00'),
(10, 4, 'SPRINT INSPIRED BY SPRITZ', 'https://play.google.com/store/apps/details?id=com.org.sprintreader', '', 'This is a special Reader inspired by Spritz! It allows you to read texts and books with incredibly fast speed. When you use Sprint Reader your average reading speed rises up to 400-700 words per minute! It''s more than 3 times faster than the average 200 wp', '<p>This is a special Reader inspired by Spritz! It allows you to read texts and books with incredibly fast speed. When you use Sprint Reader your average reading speed rises up to 400-700 words per minute! It''s more than 3 times faster than the average 200', '', 'f4678624093c8de43e83e8d68d3ede21.jpg', 1, 0, '2016-05-16 17:30:32', '0000-00-00 00:00:00'),
(11, 4, 'PERMAGRAM', 'https://play.google.com/store/apps/details?id=com.infoicontechnologies.permagramapp', '', 'Permagram, Permasteelisa, PNA', '<p>Permagram, Permasteelisa, PNA</p>', '', 'bcb9d4ae8f58f1abca0b211136d29420.jpg', 1, 0, '2016-05-16 17:31:42', '0000-00-00 00:00:00'),
(12, 4, 'BOXING SIMULATOR', 'https://play.google.com/store/apps/details?id=com.infoicon', '', 'Boxing Simulator app for boxing.This App contains videos about how to study how to become a good boxer, also contain combos , user can purchase these on ordinany charges', '<p>Boxing Simulator app for boxing.This App contains videos about how to study how to become a good boxer, also contain combos , user can purchase these on ordinany charges</p>', '', 'a707710cf86bd1e21e4d2f391230d30e.jpg', 1, 0, '2016-05-16 17:32:47', '0000-00-00 00:00:00'),
(13, 4, 'CINEBOLLY: FREE FULL HD MOVIES', 'https://play.google.com/store/apps/details?id=com.infoicon.BollyMovies', '', 'CineBolly application streams latest and most popular Bollywood and Hollywood movies directly on your phone/ tablet free of cost. All movies are absolutely free to watch.', '<p>CineBolly application streams latest and most popular Bollywood and Hollywood movies directly on your phone/ tablet free of cost. All movies are absolutely free to watch.</p>', '', '2a25f1f7b0334e947962a5d5f4ff3a08.jpg', 1, 0, '2016-05-16 17:33:47', '0000-00-00 00:00:00'),
(14, 4, 'YOGA FROM THE HEART', 'https://play.google.com/store/apps/details?id=com.infoicontechnologies.yoga&hl=en', '', 'This app serves as a source for endless inspiration and an expression of the artistic form of yoga. This app shows how one can explore the limitless possibilities of body, mind and spirit in their Yoga practice. It''s a good reference guide for Yoga Student', '<p>This app serves as a source for endless inspiration and an expression of the artistic form of yoga. This app shows how one can explore the limitless possibilities of body, mind and spirit in their Yoga practice. It''s a good reference guide for Yoga Stud', '', '03ef3a471845fe209db8537ba2e01f83.jpg', 1, 0, '2016-05-16 17:34:51', '0000-00-00 00:00:00'),
(15, 5, 'DENTAL PRACTICE MONITOR', 'https://itunes.apple.com/in/app/dental-practice-monitor/id1059307891?mt=8', '', 'Simple data input from your front office (takes less than 5 minutes a day) gives you the Doctor key practice indicator information which will assist you in effectively managing your dental business.', '<p>Simple data input from your front office (takes less than 5 minutes a day) gives you the Doctor key practice indicator information which will assist you in effectively managing your dental business.</p>', '', 'Dental.jpeg', 1, 0, '2016-05-16 18:33:21', '2016-05-16 18:36:37'),
(16, 5, 'BBR GRAPHICS', 'https://itunes.apple.com/is/app/bbr-graphics/id1093745567?mt=8', '', 'BBR Graphics latest stock machines.', '<p>BBR Graphics latest stock machines.</p>', '', 'BBR-Graphics.jpeg', 1, 0, '2016-05-16 18:39:52', '0000-00-00 00:00:00'),
(17, 5, 'POOLDESIGNESTIMATOR', 'https://itunes.apple.com/us/app/pooldesignestimator/id976882547?mt=8', '', 'The Pooldesignestimator app will provide homeowners, at their convenience, a written proposal with estimate for the inground pool they choose. The complete professional proposal is delivered to them in as little as 10 seconds.', '<p>The Pooldesignestimator app will provide homeowners, at their convenience, a written proposal with estimate for the inground pool they choose. The complete professional proposal is delivered to them in as little as 10 seconds.</p>', '', 'POOLDESIGNESTIMATOR.jpeg', 1, 0, '2016-05-16 18:41:17', '0000-00-00 00:00:00'),
(18, 4, 'Dental Practice Monitor', 'https://play.google.com/store/apps/details?id=com.infoicon.sdbm', '', 'Simple data input from your front office (takes less than 5 minutes a day) gives you the Doctor key practice indicator information which will assist you in effectively managing your dental business.', '<p>Simple data input from your front office (takes less than 5 minutes a day) gives you the Doctor key practice indicator information which will assist you in effectively managing your dental business.</p>', '', 'Dental.jpeg', 1, 0, '2016-05-16 10:04:48', '0000-00-00 00:00:00'),
(19, 5, 'EZ-DV Diminished Value Calculator', 'https://itunes.apple.com/us/app/ez-dv-diminished-value-calculator/id1095282103?ls=1&mt=8', '', 'Little known fact: If your vehicle was involved in a collision it is now worth less. This is due to perceived negative vehicle history which results in a diminished value of your vehicle.', '<p>Little known fact: If your vehicle was involved in a collision it is now worth less. This is due to perceived negative vehicle history which results in a diminished value of your vehicle.</p>', '', 'EZ_DV.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(20, 5, 'MediVisit Home GP Service', 'https://itunes.apple.com/au/app/medivisit-home-gp-service/id1060955711?mt=8', '', 'MediVisit Home GP. Please use this app to request a Bulk Billing Doctor to visit you on weeknights, weekends and public holidays.\r\n', 'MediVisit Home GP. Please use this app to request a Bulk Billing Doctor to visit you on weeknights, weekends and public holidays.\r\n', '', 'mediv.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(21, 5, 'Medvisit Home Doctor Service', 'https://itunes.apple.com/au/app/medvisit-home-doctor-service/id1052650504?mt=8', '', 'MediVisit Home GP. Please use this app to request a Bulk Billing Doctor to visit you on weeknights, weekends and public holidays.\r\n', 'MediVisit Home GP. Please use this app to request a Bulk Billing Doctor to visit you on weeknights, weekends and public holidays.\r\n', '', 'mediv2.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(22, 5, 'iPZMall for iPad - Your premier online shopping destination', 'https://itunes.apple.com/lu/app/ipzmall-for-ipad-your-premier/id1056469969?mt=8', '', 'iPZMall is an innovative site that brings your favorite designers and stores together in one place allowing you to spend less time searching the web and more time finding what you want.', 'iPZMall is an innovative site that brings your favorite designers and stores together in one place allowing you to spend less time searching the web and more time finding what you want.', '', '6103e983bc03454f64decd076e9b8185.jpg', 1, 0, '2016-05-16 10:16:23', '2016-05-19 03:10:00'),
(23, 5, 'Kidizen - Buy and Sell Kids Clothes', 'https://itunes.apple.com/us/app/kidizen-buy-sell-kids-clothes/id395245595?mt=8', '', 'The Only App You Need!!!\r\n“Absolutely LOVE this app I now do all my shopping for my little one on Kidizen! And I save SO MUCH $$$!!! This app is a must if you have young children!!” ', 'The Only App You Need!!!\r\n“Absolutely LOVE this app I now do all my shopping for my little one on Kidizen! And I save SO MUCH $$$!!! This app is a must if you have young children!!” ', '', 'kidizen.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(24, 5, 'Protek Devices', 'https://itunes.apple.com/us/app/protek-devices/id1015359494?mt=8', '', 'ProTek Devices is a leading semiconductor manufacturer of a wide range of high-performance TVS protection, analog and mixed-signal products. So by this app you can easy search the product and can see the product details.', 'ProTek Devices is a leading semiconductor manufacturer of a wide range of high-performance TVS protection, analog and mixed-signal products. So by this app you can easy search the product and can see the product details.', '', 'Protek_device.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(25, 5, 'PAHMS', 'https://itunes.apple.com/us/app/pahms/id777510856?ls=1&mt=8', '', 'We provide BULK BILLED After Hours Doctor home visits to resident of Perth Metropolitan areas. This free app will allow you to send your details to us, and one of our friendly operators will call you to book a Doctor to visit you in the comfort of your own', 'We provide BULK BILLED After Hours Doctor home visits to resident of Perth Metropolitan areas. This free app will allow you to send your details to us, and one of our friendly operators will call you to book a Doctor to visit you in the comfort of your own', '', 'pahms.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(26, 5, 'MIFAB Catalog App', 'https://itunes.apple.com/us/app/mifab-catalog-app/id885338809?ls=1&mt=8', '', 'The MIFAB Catalog app is a free source for interactive MIFAB product literature and information. To keep in line with our philosophy of eliminating unnecessary processes, this app allows you to take both our paper catalogs and our website with you on the g', 'The MIFAB Catalog app is a free source for interactive MIFAB product literature and information. To keep in line with our philosophy of eliminating unnecessary processes, this app allows you to take both our paper catalogs and our website with you on the g', '', 'mifab.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(27, 5, 'Yoga from the heart', 'https://itunes.apple.com/in/app/yoga-from-the-heart/id423478551?mt=8', '', 'This is not an instructional yoga app. This is a unique and one of a kind application in yoga as this app is specially designed for yoga students and teachers alike looking for inspiration in their practice and practice the correct pronunciation of the nam', 'This is not an instructional yoga app. This is a unique and one of a kind application in yoga as this app is specially designed for yoga students and teachers alike looking for inspiration in their practice and practice the correct pronunciation of the nam', '', 'yoga-from.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(28, 5, 'TEXAS PREMIER TITLE', 'https://itunes.apple.com/us/app/texas-premier-title/id897895780?ls=1&mt=8', '', 'Texas Premier Titles NetSheet App comes preloaded with calculations for Real Estate Professionals. It allows them to easily and quickly generate a Buyer’s Estimate and/or a Seller’s Net Sheet. Texas Premier Titles NetSheet App also allows you to call your ', 'Texas Premier Titles NetSheet App comes preloaded with calculations for Real Estate Professionals. It allows them to easily and quickly generate a Buyer’s Estimate and/or a Seller’s Net Sheet. Texas Premier Titles NetSheet App also allows you to call your ', '', 'Texas.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(29, 5, 'Fowler Kennedy ACL Prevention', 'https://itunes.apple.com/us/app/fowler-kennedy-acl-prevention/id898929371?mt=8', '', 'ACL Prevention (PAIRS) is a 10 minute structured injury prevention program for all athletes (males/females) participating in various court and field sports across all ages (teens to adults). ', 'ACL Prevention (PAIRS) is a 10 minute structured injury prevention program for all athletes (males/females) participating in various court and field sports across all ages (teens to adults). ', '', 'fowler-kennedy.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(30, 5, 'Play Oldies Music', 'https://itunes.apple.com/us/app/play-oldies-music/id457809908?mt=8', '', 'Top 100 popular music songs by Year 1950 to 1989 - Unlimited Song Plays ', 'Top 100 popular music songs by Year 1950 to 1989 - Unlimited Song Plays ', '', 'play_oldies.jpeg', 1, 0, '2016-05-16 10:16:23', '0000-00-00 00:00:00'),
(31, 5, 'Distributor K-360', 'https://itunes.apple.com/us/app/distributor-k-360/id882451101?mt=8', '', 'Demo for use during sales meetings to highlight the educational value of the K-360 iPad App', 'Demo for use during sales meetings to highlight the educational value of the K-360 iPad App', '', '140df8b9c6e3c52ecf93f86bb9d5f0ef.jpg', 1, 0, '2016-05-16 10:16:23', '2016-05-19 03:00:17'),
(32, 5, 'K-360', 'https://itunes.apple.com/us/app/k-360/id859124070?ls=1&mt=8', '', 'App Description: Combining education, training and portability, the K-360° iPad App is a very simple, effective and powerful tool to educate and communicate the benefits of K-Laser therapy. It also serves as a virtual “handbook” for the doctor and staff, s', 'App Description: Combining education, training and portability, the K-360° iPad App is a very simple, effective and powerful tool to educate and communicate the benefits of K-Laser therapy. It also serves as a virtual “handbook” for the doctor and staff, s', '', '3cf08940a429a197987f3a66a48d7780.jpg', 1, 0, '2016-05-16 10:16:23', '2016-05-19 02:57:32'),
(34, 4, 'Texas Premier Title Net Sheet', 'https://play.google.com/store/apps/details?id=com.infoicon.texaspremier', '', 'Texas Premier Titles NetSheet App comes preloaded with calculations for Real Estate Professionals. It allows them to easily and quickly generate a Buyer’s Estimate and/or a Seller’s Net Sheet. ', '<p>Texas Premier Titles NetSheet App comes preloaded with calculations for Real Estate Professionals. It allows them to easily and quickly generate a Buyer’s Estimate and/or a Seller’s Net Sheet.&nbsp;</p>', '', '006235f3b6867d497ddd08926ca936b4.jpg', 1, 0, '2016-05-17 01:38:24', '0000-00-00 00:00:00'),
(35, 4, 'Hair and Wig Styles', 'https://play.google.com/store/apps/details?id=com.directwigs', '', 'Directwigs Hair and Wig Styles gives you over 2600 Hair Styles and Wigs in the style to buy.\r\nTake your own picture to compare with the styles, Print or email up to 3 styles and your own picture to friends or hairdressers.', '<p>Directwigs Hair and Wig Styles gives you over 2600 Hair Styles and Wigs in the style to buy.</p><p>Take your own picture to compare with the styles, Print or email up to 3 styles and your own picture to friends or hairdressers.</p>', '', '380db7fc24bfff162f11a76603e01e1a.jpg', 1, 0, '2016-05-17 01:41:00', '0000-00-00 00:00:00'),
(36, 4, 'PAHMS', 'https://play.google.com/store/apps/details?id=com.app.pahms', '', 'We provide BULK BILLED After Hours Doctor home visits to resident of Perth Metropolitan areas. This free app will allow you to send your details to us, and one of our friendly operators will call you to book a Doctor to visit you in the comfort of your hom', '<p>We provide BULK BILLED After Hours Doctor home visits to resident of Perth Metropolitan areas. This free app will allow you to send your details to us, and one of our friendly operators will call you to book a Doctor to visit you in the comfort of your ', '', '53f0b4962a4e2f5c4dd794001f704c05.jpg', 1, 0, '2016-05-17 01:43:32', '0000-00-00 00:00:00'),
(37, 4, 'ProTek Devices', 'https://play.google.com/store/apps/details?id=com.infoicontechnologies.protekdevices', '', 'ProTek Devices is a leading semiconductor manufacturer of a wide range of high-performance TVS protection, analog and mixed-signal products. With over 20 years of engineering and manufacturing experience, ', '<p>ProTek Devices is a leading semiconductor manufacturer of a wide range of high-performance TVS protection, analog and mixed-signal products. With over 20 years of engineering and manufacturing experience,&nbsp;</p>', '', 'dae2de3773e7cbdbd90065feaa950c79.jpg', 1, 0, '2016-05-17 01:47:45', '0000-00-00 00:00:00'),
(38, 4, 'Groceries2Go', 'https://play.google.com/store/apps/details?id=com.infoicontechnologies.groceries2go&hl=en', '', 'Welcome to our Groceries 2 Go App, Sweet Addicts started initially as a business bringing all your favourite sweets and chocolate and have now expanded to cover a large range of products in supplying the UK and Export to your home, Cafes, Newsagents and Sm', '<p>Welcome to our Groceries 2 Go App, Sweet Addicts started initially as a business bringing all your favourite sweets and chocolate and have now expanded to cover a large range of products in supplying the UK and Export to your home, Cafes, Newsagents and', '', '1c07c7f11cc0de38d8156fc6b5986b7f.jpg', 1, 0, '2016-05-17 01:50:05', '0000-00-00 00:00:00'),
(39, 4, 'Callmum Driver', 'https://play.google.com/store/apps/details?id=com.info.callmumdriver', '', 'Accept a request of Sheffield taxi at the touch of a button quick reliable safe,', '<p>Accept a request of Sheffield taxi at the touch of a button quick reliable safe,</p>', '', '8f038ebc5cd0826aac8dafa009a822a9.jpg', 1, 0, '2016-05-17 01:52:03', '0000-00-00 00:00:00'),
(40, 4, 'Citizen Home Solutions', 'https://play.google.com/store/apps/details?id=com.infoicontechnologies.sygnus', '', 'Citizen Home Solutions is a full service moving concierge that is FAST, FREE, and EASY. We help clients connect electricity, cable, satellite, internet, phone, security, water, gas, movers, insurance, maid, and many more.', '<p>Citizen Home Solutions is a full service moving concierge that is FAST, FREE, and EASY. We help clients connect electricity, cable, satellite, internet, phone, security, water, gas, movers, insurance, maid, and many more.</p>', '', '2d628af1174e716e52deae46b63eb742.jpg', 1, 0, '2016-05-17 01:57:51', '0000-00-00 00:00:00'),
(41, 4, 'MediVisit Home GP', 'https://play.google.com/store/apps/details?id=infoicontechonogies.com.MHDS&hl=en', '', 'Medivisit Home GP Service. Please use this app to request a Bulk Billing Doctor to visit you on weeknights, weekends and public holidays.', '<p>Medivisit Home GP Service. Please use this app to request a Bulk Billing Doctor to visit you on weeknights, weekends and public holidays.</p>', '', '69a28462684b6460d1065914da00f646.jpg', 1, 0, '2016-05-17 02:01:02', '0000-00-00 00:00:00'),
(42, 4, 'EZ-DV Diminished Value Calc', 'https://play.google.com/store/apps/details?id=com.infoicon.diminishedvaluecalculator', '', 'Inherent diminished value (what we calculate) is the resale value lost on a vehicle following a collision. This is due to the perceived negative vehicle history that is now attached to that vehicle when compared to a similar vehicle without the negative hi', '<p>Inherent diminished value (what we calculate) is the resale value lost on a vehicle following a collision. This is due to the perceived negative vehicle history that is now attached to that vehicle when compared to a similar vehicle without the negative', '', '624555a9fb1cbb3da902743066dd5f1b.jpg', 1, 0, '2016-05-17 02:03:24', '0000-00-00 00:00:00'),
(43, 4, 'Lengua Translation Quote', 'https://play.google.com/store/apps/details?id=com.infoicon.lengua', '', 'Download our app and we will send you free quotes for your translation immediately. All languages available. With our app you can send requests for translation quotes directly from your mobile device and you will get your quote within 24 hours or faster.', '<p>Download our app and we will send you free quotes for your translation immediately. All languages available. With our app you can send requests for translation quotes directly from your mobile device and you will get your quote within 24 hours or faster', '', '00e95693b1fc52660e853f7e8688b8d3.jpg', 1, 0, '2016-05-17 02:05:44', '0000-00-00 00:00:00'),
(44, 1, 'Speedy Sydney Removalist', 'http://www.speedysydneyremovalist.com.au/', '', 'Speedy Sydney Removalist', '<p>Speedy Sydney Removalist</p>', '0f6c9b32aa882664731a94a534f03afd.jpg', 'cfdacffe4959ac94777eacba142edaed.jpg', 1, 1, '2016-05-18 02:11:01', '0000-00-00 00:00:00'),
(45, 8, 'Sensatia', 'https://www.sensatia.com ', '', 'Sensatia', '<p>Sensatia</p>', 'b5ad6e234b45a69fdf2eab8009dea3a0.jpg', 'fe3ae177c652331145ad81900b17e8b3.jpg', 1, 0, '2016-05-19 06:48:34', '0000-00-00 00:00:00'),
(46, 1, 'Eolas Technology', 'http://www.eolastechnology.com/', '', 'Eolas Technology', '<p>Eolas Technology</p>', '028e09217a8987f6b3922eba7a7e89bb.jpg', '15356600e3e7802f36af7e1711a71fec.jpg', 1, 1, '2016-05-18 02:13:49', '0000-00-00 00:00:00'),
(47, 7, 'OlayaBeach', 'http://www.olayabeach.com/', '', 'OlayaBeach', '<p>OlayaBeach</p>', '9345720d8938f373b9fbd32bb97491d8.jpg', '6dacd02b5df82a9d97f695c3ee39999f.jpg', 1, 1, '2016-05-18 02:14:53', '2016-05-18 02:18:02'),
(48, 8, 'Hydro Planet', 'http://www.hydroplanet.eu/', '', 'Hydro Planet', '<p>Hydro Planet</p>', '1b249a9c24014db3150c7ea8c4cbdf93.jpg', 'd832e935c15b5a73d4a201564e1af027.jpg', 1, 0, '2016-05-18 02:39:23', '0000-00-00 00:00:00'),
(49, 1, 'USA Records Search', 'https://www.usarecordssearch.com/', '', 'USA Records Search', '<p>USA Records Search</p>', '2e8860841097ce44162278f20f7d8c8d.jpg', 'e84958cb24cbc2d409887891282cdd2b.jpg', 1, 0, '2016-05-18 02:20:53', '0000-00-00 00:00:00'),
(50, 1, 'Entire IT Solutions', 'http://www.entire-it.co.uk/', '', 'Entire IT Solutions', '<p>Entire IT Solutions</p>', 'b77d5c3ced41ccd3f993a378ed01b73d.jpg', 'f250a1125164bc68c5c8b90ea1ea8941.jpg', 1, 0, '2016-05-18 02:22:06', '0000-00-00 00:00:00'),
(51, 8, 'Melekemue Lighting', 'http://www.melekemuelighting.com', '', 'Melekemue Lighting', '<p>Melekemue Lighting</p>', '32c0fbcfeff8c50f0d2f899a075d2411.jpg', '734707e8cf016b03f507a724cf413287.jpg', 1, 1, '2016-05-18 07:51:32', '0000-00-00 00:00:00'),
(52, 1, 'Locksmithnyc intercom', 'http://locksmithnyc-intercom.com/', '', 'Locksmithnyc intercom', '<p>Locksmithnyc intercom</p>', 'b71acf1583b360c35468ec72b34dba45.jpg', '9d147196e3e7630314b00ad1a8a1cdb1.jpg', 1, 0, '2016-05-18 02:24:41', '0000-00-00 00:00:00'),
(53, 1, 'DJ Magic', 'http://discjockeymagic.com/', '', 'DJ Magic', '<p>DJ Magic</p>', 'f4a9a652755abf704d1c458162b3ce73.jpg', '6854a1dd9bcfa4489c470347c6867248.jpg', 1, 0, '2016-05-18 02:26:05', '0000-00-00 00:00:00'),
(54, 14, 'Super Pages', 'http://www.superpages.com.au', '', 'Super Pages', '<p>Super Pages</p>', '892a11e54f4c344479fdcc63f9606e2a.jpg', '777888dd6e8d22f74b759115428c510c.jpg', 1, 0, '2016-05-19 08:08:31', '0000-00-00 00:00:00'),
(55, 14, 'Military-Travel.net', 'http://www.military-travel.net', '', 'Military-Travel.net', '<p>Military-Travel.net</p>', '8f18063c31b7997c8322ce1b27b50bf6.jpg', 'dfb58771898a7c237e654ecca0166e3f.jpg', 1, 0, '2016-05-19 08:17:51', '0000-00-00 00:00:00'),
(56, 14, 'Big Barrel', 'http://bigbarrel.co.nz', '', 'Big Barrel', '<p>Big Barrel</p>', '59fe787c6826860ac4732fa7886ad74f.jpg', 'e3e4e43d6858f756d929eacd8f814b2d.jpg', 1, 0, '2016-05-19 08:20:07', '2016-05-19 08:21:49'),
(57, 9, 'Automakler Frankfurt', 'http://automakler-frankfurt.de/', '', 'Automakler Frankfurt', '<p>Automakler Frankfurt</p>', 'a81e4922142d5629fa8b38bd3583bcb1.jpg', 'd2ffe92d85acb9bed42783a284547af4.jpg', 1, 0, '2016-05-18 02:35:26', '0000-00-00 00:00:00'),
(58, 8, 'lapsi', 'http://www.lapsi.co.uk/', '', 'lapsi', '<p>lapsi</p>', 'a58af305d4ce3ba28ab25aeb0e6e1311.jpg', '4648b3f674de7a372670adda0b6c2f0c.jpg', 1, 0, '2016-05-18 02:36:40', '0000-00-00 00:00:00'),
(59, 8, 'latiniusa', 'http://latiniusa.com/', '', 'latiniusa', '<p>latiniusa</p>', '55a00a34580370db5947b4ae12a93c0e.jpg', '1f80a84ee555ade6397596f200d6cd3d.jpg', 1, 0, '2016-05-18 02:37:44', '2016-05-19 05:01:24'),
(60, 1, 'Vickers Research Institute', 'http://vickersresearchinstitute.com/', '', 'Vickers Research Institute', '<p>Vickers Research Institute</p>', 'e720c35cfd3074d0c733703a8ef47133.jpg', '87954644a00a6b64bf4b6f160a3081f1.jpg', 1, 0, '2016-05-18 02:19:40', '0000-00-00 00:00:00'),
(61, 1, 'City Wide Appliance', 'http://www.citywideappliance.ca/', '', 'City Wide Appliance', '<p>City Wide Appliance</p>', 'a5ac5ca3553d0e1d57ec59eb240cb39b.jpg', 'd340ddcee999e72f63aa23ded03227f9.jpg', 1, 0, '2016-05-18 02:41:29', '0000-00-00 00:00:00'),
(62, 1, 'Heavenly Palace', 'http://www.heavenlypalace.com/', '', 'Heavenly Palace', '<p>Heavenly Palace</p>', 'd2634d6dd93287c715e33cf765b9a978.jpg', 'fb68e307982c668ba67a0a61d85f9520.jpg', 1, 1, '2016-05-18 02:43:14', '0000-00-00 00:00:00'),
(63, 8, 'Herbal Ayurvedic Medicine', 'http://www.vrindavanayurvedic.com', '', 'Herbal Ayurvedic Medicine', '<p>Herbal Ayurvedic Medicine</p>', '362f00b802eb47b0ca8fce1db87401d8.jpg', 'cb82deac8527aa77614f73390d3155fe.jpg', 1, 1, '2016-05-18 07:47:45', '0000-00-00 00:00:00'),
(64, 8, 'Stella and Minx', 'http://www.stellaandminx.com.au/', '', 'Stella and Minx', '<p>Stella and Minx</p>', '2771c2e3a191343599eaccda5ce7a90a.jpg', '14b887ceb9b4dc3e8bf456b208d2a62d.jpg', 1, 1, '2016-05-18 07:50:22', '0000-00-00 00:00:00'),
(65, 1, 'iduba info', 'http://iduba.info/', '', 'iduba info', '<p>iduba info</p>', '425ff2efe3d4dc561788b2215ef1cda8.jpg', '8f49a5d1b22d335dad31f959239af15e.jpg', 1, 0, '2016-05-18 02:23:30', '0000-00-00 00:00:00'),
(66, 8, 'Adriana Minari', 'http://www.adrianaminari.com', '', 'Adriana Minari', '<p>Adriana Minari</p>', 'c055f6659319d35877871f4e14ae536c.jpg', '67340177f8b0fb8c1999f36374a2e05e.jpg', 1, 1, '2016-05-18 07:52:54', '0000-00-00 00:00:00'),
(67, 1, 'My Lashes', 'http://www.my-lashes.co.uk', '', 'My Lashes', '<p>My Lashes</p>', '80d8835f205f4ffbfdaf5f7c8aeb25e2.jpg', '8c069b4bb968282f0d2254aa9a5c9ed0.jpg', 1, 1, '2016-05-18 07:54:57', '0000-00-00 00:00:00'),
(68, 1, 'Happy Hands', 'http://www.happy-hands.biz', '', 'Happy Hands', '<p>Happy Hands</p>', '6a04c591bdfc718a9d8f765b0bf5bae2.jpg', '89d421a2a965f4c05b140b17ef14f078.jpg', 1, 1, '2016-05-18 07:56:07', '0000-00-00 00:00:00'),
(69, 1, 'Art Flooring & Construction', 'http://www.artflooringcompany.com', '', 'Art Flooring & Construction', '<p>Art Flooring &amp; Construction</p>', '827da0a5f363d742f22f50932b3a1416.jpg', '943b10309e8701baa88634230c5395ab.jpg', 1, 1, '2016-05-18 07:57:41', '0000-00-00 00:00:00'),
(70, 1, 'EDMAN', 'http://www.edman.tv', '', 'EDMAN', '<p>EDMAN</p>', 'e13178023f34dddc72436f5dbe38de83.jpg', 'efdb580b92169d52908bdd9b349cfdb1.jpg', 1, 1, '2016-05-18 08:13:43', '0000-00-00 00:00:00'),
(71, 1, 'London Groove', 'http://www.londongroove.co.uk', '', 'London Groove', '<p>London Groove</p>', '9561f7768b519cd606ff3259bda8cda5.jpg', '4b921ea0387a4d7f528972c200cd811e.jpg', 1, 1, '2016-05-18 08:14:51', '0000-00-00 00:00:00'),
(72, 1, 'Food Control Consultants Ltd', 'http://www.food-control.com', '', 'Food Control Consultants Ltd', '<p>Food Control Consultants Ltd</p>', 'cbf6829037995a0a6690c4e1f2755aae.jpg', 'e355043921fe604b9127f6151c858714.jpg', 1, 1, '2016-05-18 08:16:13', '0000-00-00 00:00:00'),
(73, 1, 'Team Works Performance', 'http://www.teamworksperformance.com', '', 'Team Works Performance', '<p>Team Works Performance</p>', 'bbc9a6937f88142c965a944af27a5ca2.jpg', 'f4cb3156fc4b0d8c2cfd838cf71e7c8d.jpg', 1, 1, '2016-05-18 08:17:38', '0000-00-00 00:00:00'),
(74, 1, 'Black Tiger', 'http://www.blacktiger.com.au', '', 'Black Tiger', '<p>Black Tiger</p>', 'f571b04e19fabfce7b1936705abeb039.jpg', 'c0f536267d9b79b13846482a5b00bea0.jpg', 1, 1, '2016-05-18 08:21:14', '0000-00-00 00:00:00'),
(75, 1, 'Sweet Market', 'http://www.sweetmarket.com.au', '', 'Sweet Market', '<p>Sweet Market</p>', '7e26f98f533adbc56536fe9a2fdec023.jpg', '37b70c431f4f1e7ab5d9023f7c8d3663.jpg', 1, 1, '2016-05-18 08:29:53', '0000-00-00 00:00:00'),
(76, 1, 'Club Touriste', 'http://www.clubtouriste.ca', '', 'Club Touriste', '<p>Club Touriste</p>', '070588455eed8ad5696b67d35bc9f03b.jpg', 'ccaeabf43b71bddb7686209d5cb39988.jpg', 1, 1, '2016-05-18 08:32:09', '0000-00-00 00:00:00'),
(77, 1, 'Construction Cicerone', 'http://www.constructioncicerone.com', '', 'Construction Cicerone', '<p>Construction Cicerone</p>', 'c60ed6d758db683ce72a91844fdd1916.jpg', '37c0b0b1273bbc72c810f6c98f5f23a7.jpg', 1, 1, '2016-05-18 08:34:06', '0000-00-00 00:00:00'),
(78, 1, 'Gift Card Printers', 'http://www.giftcardprinters.ca', '', 'Gift Card Printers', '<p>Gift Card Printers</p>', '754bf60f0c295c218554626cc92dfa95.jpg', '15a0cf875eae2a5d7aa90dcd0509b680.jpg', 1, 1, '2016-05-18 08:36:00', '0000-00-00 00:00:00'),
(79, 1, 'IT&T Australia', 'http://www.2communicate.com.au', '', 'IT&T Australia', '<p>IT&amp;T Australia</p>', 'b81965404df35d06b0ddcc368e28d971.jpg', 'a8443397998f2801537141c8ef93b92d.jpg', 1, 1, '2016-05-18 08:37:31', '0000-00-00 00:00:00'),
(80, 1, 'Logo Label Printing', 'http://www.logolabelprinting.com', '', 'Logo Label Printing', '<p>Logo Label Printing</p>', '0b6755241f8101a64a7aa3fad09c33c4.jpg', '9cb48afcd0c1f8d0ad92bd840796ae88.jpg', 1, 1, '2016-05-18 08:38:36', '0000-00-00 00:00:00'),
(81, 8, 'The Saree Shop', 'http://www.thesareeshop.com', '', 'The Saree Shop', '<p>The Saree Shop</p>', '224e67f294013cac336bbf55d847c3c1.jpg', 'b3c952e12c5dd04af09630f89f032dab.jpg', 1, 1, '2016-05-18 08:39:24', '2016-05-21 09:23:41'),
(82, 1, 'House Of Stone', 'http://www.houseofstone.ie', '', 'House Of Stone', '<p>House Of Stone</p>', '0e2f8df0e0a2b57382740a6346e5388d.jpg', 'bc5684163a997e90143f362f5e3e1e2f.jpg', 1, 0, '2016-05-18 08:40:45', '0000-00-00 00:00:00'),
(83, 1, 'AD Flags', 'http://www.adflags.eu/', '', 'AD Flags', '<p>AD Flags</p>', '7dc8e6e569f90245e5919fdbcf5d3819.jpg', '5368ddb6d3ded9e4f589fc34b78c7fd3.jpg', 1, 0, '2016-05-18 08:42:00', '0000-00-00 00:00:00'),
(84, 1, 'Time Scape', 'http://www.timescapeusa.com/', '', 'Time Scape', '<p>Time Scape</p>', '7d773324734f3e9d74a4eca1e8acce8a.jpg', 'bc903e9565757ab2be3dc6c4a634a117.jpg', 1, 0, '2016-05-18 08:43:41', '0000-00-00 00:00:00'),
(85, 10, 'Cigna', 'http://www.cigna.com', '', 'Cigna', '<p>Cigna</p>', 'b425a891b4433c4625ac4de16e7533bc.jpg', '3dfc8ec1fd8db5178ec0b16d3467e211.jpg', 1, 0, '2016-05-18 08:53:09', '0000-00-00 00:00:00'),
(86, 10, 'Random Storm', 'https://www.randomstorm.com', '', 'Random Storm', '<p>Random Storm</p>', '49e74d053f83a31f69e9f9679fab12f3.jpg', '1ec2ad00efd6a6709ec02b83f306afd3.jpg', 1, 0, '2016-05-18 08:54:17', '0000-00-00 00:00:00'),
(87, 10, 'Fast Printing Australia', 'http://www.fastprinting.com.au', '', 'Fast Printing Australia', '<p>Fast Printing Australia</p>', '4eb9796d13ed1b1cf4c8393ce68147fa.jpg', '9fc95d229c81ff341319c795f6b7de91.jpg', 1, 0, '2016-05-18 08:55:57', '0000-00-00 00:00:00'),
(88, 1, 'Marquee Solutions', 'http://www.marqueesolutions.ie', '', 'Marquee Solutions', '<p>Marquee Solutions</p>', '8d6e442624d16b018beeae69c6429d66.jpg', '155005191c7e5839e85ebf0916ecb409.jpg', 1, 0, '2016-05-18 09:00:02', '0000-00-00 00:00:00'),
(89, 11, 'JST Nutrition', 'http://www.jst-nutrition.com', '', 'JST Nutrition', '<p>JST Nutrition</p>', '44478b09d777be8d01f38359a0087062.jpg', 'ec86821c695ed91435b065ff7b97cbde.jpg', 1, 0, '2016-05-18 09:08:21', '2016-05-18 09:11:25'),
(90, 5, 'Hair and Wig Styles', 'https://itunes.apple.com/us/app/hair-and-wig-styles/id910059064?ls=1&mt=8', '', 'Directwigs Hair and Wig Styles gives you over 2600 Hair Styles and Wigs in the style to buy.\r\nTake your own picture to compare with the styles, Print or email up to 3 styles and your own picture to friends or hairdressers.', '<p>Directwigs Hair and Wig Styles gives you over 2600 Hair Styles and Wigs in the style to buy.</p><p>Take your own picture to compare with the styles, Print or email up to 3 styles and your own picture to friends or hairdressers.</p>', '', 'f6bd72c99d432077617e0bbccb6bf475.jpg', 1, 0, '2016-05-19 02:40:46', '0000-00-00 00:00:00'),
(91, 5, 'Freight Bulk Road', 'https://itunes.apple.com/us/app/freight-bulk-road/id830314705?ls=1&mt=8', '', 'Easily calculate your Bulk Road Freight from Dollars a Ton, to cents a kilometre ton, and dollars a kilometre.', '<p>Easily calculate your Bulk Road Freight from Dollars a Ton, to cents a kilometre ton, and dollars a kilometre.</p>', '', '144b053d8e8172fa294a4bc2770a6404.jpg', 1, 0, '2016-05-19 02:51:03', '2016-05-19 02:55:12'),
(92, 5, 'Eduwizards Prep', 'https://play.google.com/store/apps/details?id=com.sai.android.eduwizard&hl=en', '', 'Eduwizards Prep is a Test Prep app for India based competitive and entrance exam preparation. This app enables users to take Tests in Online and Offline mode using mobile devices. With this app user can access a database of 100,000+ questions.', '<p>Eduwizards Prep is a Test Prep app for India based competitive and entrance exam preparation. This app enables users to take Tests in Online and Offline mode using mobile devices. With this app user can access a database of 100,000+ questions.</p>', '', 'e2a5709910d972d19335cdbfb4779465.jpg', 1, 0, '2016-05-19 03:14:08', '0000-00-00 00:00:00'),
(93, 1, 'Globe POS Systems Inc', 'http://www.globepos.ca', 'e9960313f37c0914c0af6361766a09a2.png', 'Globe POS Systems Inc', '<p>Globe POS Systems Inc</p>', '2922447c53cf97c33b4cbe010090ce11.jpg', '859ebb61d2e9052fc04427c06f117e83.jpg', 1, 1, '2016-04-19 15:08:10', '2016-05-21 09:01:02'),
(95, 1, 'Obsidian Beauty', 'http://obsidianbeauty.com/', '', 'Obsidian Beauty', '<p>Obsidian Beauty</p>', '3f3e549b8d99aed2cea08201cab6cb65.jpg', '7367a092352af3ab834979cb05a298db.jpg', 1, 0, '2016-05-19 06:47:06', '0000-00-00 00:00:00'),
(96, 1, 'Sweeney''s of Kilbride', 'http://sweeneyskilbride.com/', '', 'Sweeney''s of Kilbride', '<p>Sweeney''s of Kilbride</p>', 'ba6252c4d33f8763d1993faee9eaa017.jpg', '85a707a51b18705410230ddacb315cf2.jpg', 1, 1, '2016-05-18 02:12:27', '0000-00-00 00:00:00'),
(97, 12, 'Groceries2go', 'http://www.groceries2go.co.uk ', '', 'Groceries2go', '<p>Groceries2go</p>', 'bbd4975c29e72b575f4ec74dd0aff22f.jpg', '41c1e0216f64924bcd21fd79daa58513.jpg', 1, 0, '2016-05-19 06:55:38', '0000-00-00 00:00:00'),
(98, 13, 'GBR Nutrition', 'http://www.gbrnutrition.com/', '', 'GBR Nutrition', '<p>GBR Nutrition</p>', '336f610aa569ef67ee666fa16d99b89c.jpg', '2e9c6db18a01e2cfeef18255bed817bb.jpg', 1, 0, '2016-05-19 06:59:48', '0000-00-00 00:00:00'),
(99, 9, 'Stewarts Plumbing', 'http://www.stewartsplumbing.co.uk', '', 'Stewarts Plumbing', '<p>Stewarts Plumbing</p>', '587bcc792460fcad61a6f8f98451fa27.jpg', 'ee35c513b17488db7f7d30faaac60cd6.jpg', 1, 0, '2016-05-19 07:01:17', '0000-00-00 00:00:00'),
(100, 13, 'WARREN FAHEY', 'http://www.warrenfahey.com/', '', 'WARREN FAHEY', '<p>WARREN FAHEY</p>', 'd4c4b613c5a15cf932aeb30f2f6402b8.jpg', 'fea3ab53f661cbcfc52d73fcc3ba9dff.jpg', 1, 0, '2016-05-19 07:03:10', '0000-00-00 00:00:00'),
(101, 13, 'MN labs', 'http://www.mnlabs.net/', '', 'MN labs', '<p>MN labs</p>', '001330315539316c7472a2d5c0c99705.jpg', '86c36ec5cdefdc029c028af871e46172.jpg', 1, 0, '2016-05-19 07:04:40', '0000-00-00 00:00:00'),
(103, 8, 'Banderole stop', 'http://www.banderolestop.fr/', '', 'Banderole stop', '<p>Banderole stop</p>', '4c641c6d39e589b531dad360cd2f753e.jpg', '96482775fa661be7040f0ebc1d9d9c21.jpg', 1, 0, '2016-05-19 07:10:00', '0000-00-00 00:00:00'),
(104, 14, 'Achandak', 'http://www.achandak.com/', '', 'Achandak', '<p>Achandak</p>', '1bb53b4aa6a1c4ac582ea9a1008f7d4a.jpg', '389fbafef62f326ec04060eaa86fde2e.jpg', 1, 0, '2016-05-19 07:12:11', '0000-00-00 00:00:00'),
(105, 14, 'Idbadges', 'http://idbadges.ca', '', 'Idbadges', '<p>Idbadges</p>', 'bed3560a9810662ef6c9f50e057b6814.jpg', 'ad3cdf04af676ca4f8cd1410b1c5815c.jpg', 1, 0, '2016-05-19 07:14:09', '0000-00-00 00:00:00'),
(106, 14, 'EWM', 'http://www.everywattmatters.com/', '', 'EWM', '<p>EWM</p>', '873a6898946118d28781a1fa1e5e71aa.jpg', '5e21ffcbd899d5a8007d6d01eb0acf35.jpg', 1, 0, '2016-05-19 07:51:59', '2016-05-19 08:06:10'),
(107, 4, 'Taxi By Callmum', 'https://play.google.com/store/apps/details?id=callmum.com.info.myapplication', '', 'Getting around town couldn''t be easier. Book a Sheffield taxi and get to that all-important business meeting, your favorite restaurant or the next shopping spree in style. ', '<p>Getting around town couldn''t be easier. Book a Sheffield taxi and get to that all-important business meeting, your favorite restaurant or the next shopping spree in style.&nbsp;</p>', '', 'd3c84f3e830f605dfdda84e57e39183c.jpg', 1, 0, '2016-05-19 08:07:01', '0000-00-00 00:00:00'),
(108, 1, 'AMS U.K. (NI) Ltd', 'http://amslabs.co.uk/', '', 'AMS U.K. (NI) Ltd', '<p>AMS U.K. (NI) Ltd</p>', '780610e9ba0c34196dff92798784980d.jpg', '3ef186942e3ccba380bbd6709e565137.jpg', 1, 0, '2016-05-18 02:27:30', '0000-00-00 00:00:00'),
(109, 5, 'Taxi by CallMum', 'https://itunes.apple.com/us/app/taxi-by-callmum/id1099452221?mt=8', '', 'Getting around town couldn''t be easier. Book a Sheffield taxi and get to that all-important business meeting, your favorite restaurant or the next shopping spree in style.', '<p>Getting around town couldn''t be easier. Book a Sheffield taxi and get to that all-important business meeting, your favorite restaurant or the next shopping spree in style.</p>', '', '2094d4e7fab89f38ff3e562ec7ac7384.jpeg', 1, 0, '2016-05-19 08:11:57', '2016-05-19 10:07:45'),
(110, 5, 'Callmum Driver', 'https://itunes.apple.com/us/app/callmum-driver/id1099135311?mt=8', '', 'Accept a request of Sheffield taxi at the touch of a button quick reliable safe.\r\nContinued use of GPS running in the background can dramatically decrease battery life.', '<p>Accept a request of Sheffield taxi at the touch of a button quick reliable safe.</p><p>Continued use of GPS running in the background can dramatically decrease battery life.</p>', '', 'bb4e43bfe275a8887b2fe6a3317d9393.jpeg', 1, 0, '2016-05-19 08:13:07', '2016-05-19 10:04:43'),
(111, 5, 'Designform Furnishings', 'https://itunes.apple.com/us/app/designform-furnishings/id1108822017?ls=1&mt=8', '', 'We’re in the business of creating reliable, commercial grade furniture for the hospitality industry. If you’re a designer, architect, restaurateur or a casual lookie-loo—all of our products are here complete with product cut sheets. ', '<p>We’re in the business of creating reliable, commercial grade furniture for the hospitality industry. If you’re a designer, architect, restaurateur or a casual lookie-loo—all of our products are here complete with product cut sheets. </p>', '', '35d86e66f1ecbc3896971965f64c5a3b.jpeg', 1, 0, '2016-05-19 08:17:49', '2016-05-19 10:02:20'),
(112, 1, 'BBR Graphics', 'http://www.bbrgraphics.com/', '', 'BBR Graphics', '<p>BBR Graphics</p>', 'ce1017062ac34d7c43cd68612b59aacd.jpg', 'fa5f21da80fb7d1fc1decf071d80eeb9.jpg', 1, 0, '2016-05-18 02:28:30', '0000-00-00 00:00:00'),
(113, 1, 'Tecno Pol', 'http://tecnopol.net/', '', 'Tecno Pol', '<p>Tecno Pol</p>', '3f6a4b99ed41c4a7bc16952b90363e9f.jpg', 'a8417b7747207f997471f01f15e16441.jpg', 1, 0, '2016-05-18 02:30:00', '0000-00-00 00:00:00'),
(114, 4, 'KidsBSafe', 'https://play.google.com/store/apps/details?id=com.Infoicon.KidsBSafeNew', '', 'KidsBSafe app allows you to stay in touch with your child, when you can’t be there in person. \r\nSAFETY - TRUST - FUN \r\nSo, hand your current Android Smart Phone to your child – with our KidsBSafe app on it!', '<p>KidsBSafe app allows you to stay in touch with your child, when you can’t be there in person.&nbsp;</p><p>SAFETY - TRUST - FUN&nbsp;</p><p>So, hand your current Android Smart Phone to your child – with our KidsBSafe app on it!</p>', '', '4215b94ce3142408ae29aed3d4ee996b.jpg', 1, 0, '2016-05-19 08:48:35', '0000-00-00 00:00:00'),
(115, 2, 'Talk2Good', 'http://talk2good.com/', '', 'Talk2Good', '<p>Talk2Good</p>', '62dc8dce58af75307df604efdf9f3ac4.jpg', 'd98e91b857735e347a2376ec5126c520.jpg', 1, 0, '2016-05-19 08:49:17', '0000-00-00 00:00:00'),
(116, 1, 'Capstone Group', 'http://www.capstonegroup.net.au/', '', 'Capstone Group', '<p>Capstone Group</p>', '55931b03c3ded0ea6f66659278a741a6.jpg', '7bfd986b78d2a7faceff65e537b5bf7b.jpg', 1, 0, '2016-05-21 09:34:58', '0000-00-00 00:00:00'),
(117, 1, 'Cwbuilders Liverpool', 'http://cwbuildersliverpool.co.uk/', '', 'Cwbuilders Liverpool', '<p>Cwbuilders Liverpool</p>', '0a90d706f0173b919cb5b1d2282ed8bc.jpg', '599cc45c7cc5fc25addf6556f533c50f.jpg', 1, 0, '2016-05-21 09:36:26', '0000-00-00 00:00:00'),
(118, 1, 'Dublindiamond Factory', 'http://www.dublindiamondfactory.ie', '', 'Dublindiamond Factory', '<p>Dublindiamond Factory</p>', '2a4371e005a004a419007abe7bfb67be.jpg', '7f57de0c568d674001b3836fbbde7454.jpg', 1, 0, '2016-05-21 09:39:07', '0000-00-00 00:00:00'),
(119, 1, 'Easyfix', 'http://www.easyfix.net.au/', '', 'Easyfix', '<p>Easyfix</p>', '581da04b6d3c92659648961951bf695e.jpg', '119055e4f42d73b213a51d555a2ac837.jpg', 1, 0, '2016-05-21 09:40:22', '0000-00-00 00:00:00'),
(120, 1, 'Eescape marketing', 'http://eescapemarketing.com', '', 'Eescape marketing', '<p>Eescape marketing</p>', 'b1097e8f10a9628e0dcd7ec34ef052fe.jpg', '6837e555c88ae4e545146cc36eb4262b.jpg', 1, 0, '2016-05-21 09:41:07', '0000-00-00 00:00:00'),
(121, 1, 'Garylross', 'http://www.garylross.com', '', 'Garylross', '<p>Garylross</p>', '96fd56a7a8ae86f770b489e8f8419f6c.jpg', '371b0c7a557e2a8a2b07850e01e1f057.jpg', 1, 0, '2016-05-21 09:42:06', '0000-00-00 00:00:00'),
(122, 1, 'Sportsbetting Online', 'http://sportsbetting-online.co.uk', '', 'Sportsbetting Online', '<p>Sportsbetting Online</p>', 'dd17290dd79c3b682eaa437ea97838a5.jpg', 'a707d0f834c42de4cb167f006b792357.jpg', 1, 0, '2016-05-21 09:43:52', '0000-00-00 00:00:00'),
(123, 1, 'Smashhit Solutions', 'http://smashhitsolutions.com', '', 'Smashhit Solutions', '<p>Smashhit Solutions</p>', 'e6c6f00bc7f20036ec5f33fc0205d624.jpg', 'c1a300bda33384b1905cc7b8fa861b27.jpg', 1, 0, '2016-05-21 09:45:27', '0000-00-00 00:00:00'),
(124, 1, 'Showtime golf', 'http://www.showtimegolf.com', '', 'Showtime golf', '<p>Showtime golf</p>', 'f111d8a057f9a85191d13d6e48a103c6.jpg', '729ef3235facb96c27a8ebcb12a80e71.jpg', 1, 0, '2016-05-21 09:46:46', '0000-00-00 00:00:00'),
(125, 1, 'Sadhavideo', 'http://www.sadhavideo.com', '', 'Sadhavideo', '<p>Sadhavideo</p>', '5b1f06d9bfa7e5374d4a16947ab6bea3.jpg', 'a49bd28655c4ecdb431b631175874af1.jpg', 1, 0, '2016-05-21 09:48:08', '0000-00-00 00:00:00'),
(126, 14, 'Rkwatch house', 'http://www.rkwatchhouse.co.uk', '', 'Rkwatch house', '<p>Rkwatch house</p>', '8933aeae4c424a1151fdc1d57023a0fe.jpg', 'a0c159592e1a6325a2258141574c006c.jpg', 1, 0, '2016-05-21 09:49:15', '0000-00-00 00:00:00'),
(127, 14, 'Mecca', 'http://mecca.com.au', '', 'Mecca', '<p>Mecca</p>', 'e0820496a3fa12277b19b7a594f2a498.jpg', '0bd33bd0aedef937c8d52d64bbdb0826.jpg', 1, 0, '2016-05-21 09:50:32', '0000-00-00 00:00:00'),
(128, 1, 'Rainbowangels home', 'http://www.rainbowangelshome.com', '', 'Rainbowangels home', '<p>Rainbowangels home</p>', 'd853c73f711651f9f6b6e175ba0c11c3.jpg', 'b47273717826d0a89d1de0876de35c37.jpg', 1, 0, '2016-05-21 09:51:48', '0000-00-00 00:00:00'),
(129, 1, 'Radiusbikesand Accessories', 'http://www.radiusbikesandaccessories.com', '', 'Radiusbikesand Accessories', '<p>Radiusbikesand Accessories</p>', '504c170377263fadd9c1e7585ee69ace.jpg', '5cc5685ed12cbbeed9622ba4e44a7000.jpg', 1, 0, '2016-05-21 09:52:54', '0000-00-00 00:00:00'),
(130, 1, 'Professorgatrad', 'http://www.professorgatrad.com', '', 'Professorgatrad', '<p>Professorgatrad</p>', '7e34a374ba2b6ef678889c57ba93a0d6.jpg', 'ff8672df2ed29e50492b4a2178510a29.jpg', 1, 0, '2016-05-21 09:54:11', '0000-00-00 00:00:00'),
(131, 1, 'Newdelhiindianrestaurant', 'http://newdelhiindianrestaurant.it', '', 'Newdelhiindianrestaurant', '<p>Newdelhiindianrestaurant</p>', '91998303fb25997129ec7a3d9ce7a6a4.jpg', '78e4d1501ff4473da591f4366391e0ce.jpg', 1, 0, '2016-05-21 09:55:15', '0000-00-00 00:00:00'),
(132, 1, 'Metrogypsie', 'http://www.metrogypsie.org', '', 'Metrogypsie', '<p>Metrogypsie</p>', '53f4afebea02ccb9fe777c7853db94f1.jpg', '2077baa4aecf6ab0a2041254067c0510.jpg', 1, 0, '2016-05-21 09:56:55', '0000-00-00 00:00:00'),
(133, 1, 'Dreamarkentertainment', 'http://dreamarkentertainment.com', '', 'Dreamarkentertainment', '<p>Dreamarkentertainment</p>', '0a18e24fd96bde46f49ccfaa40914c9c.jpg', 'b154b835784f8dd195b37832fe272cda.jpg', 1, 0, '2016-05-21 09:58:16', '0000-00-00 00:00:00'),
(134, 1, 'Caijiana', 'http://caijiana.com', '', 'Caijiana', '<p>Caijiana</p>', '10c762061c6b0e48f6d98a21d6007bee.jpg', '9f9a7c4eaa07ae49056bbbe5d755696c.jpg', 1, 0, '2016-05-21 09:59:00', '0000-00-00 00:00:00'),
(135, 1, '2mbackup', 'http://www.2mbackup.com/', '', '2mbackup', '<p>2mbackup</p>', '564fd615b256bcc1e5bd31ea5000b79a.jpg', '93a4f522ff9469b9fcf7ebccc13fcfb5.jpg', 1, 0, '2016-05-21 10:00:39', '0000-00-00 00:00:00'),
(136, 1, 'Hsaoa', 'http://www.hsaoa.com', '', 'Hsaoa', '<p>Hsaoa</p>', '0cbe8505e8d2259e2eb4b0427bd05b29.jpg', '46f45f8d5188615f5f6d2669b2d541de.jpg', 1, 0, '2016-05-21 10:01:38', '0000-00-00 00:00:00'),
(137, 1, 'Igeosoftware', 'http://www.igeosoftware.com', '', 'Igeosoftware', '<p>Igeosoftware</p>', '560437f1c6dd3776b7ec2d072f0b5523.jpg', 'f71842cb048a2a441354a6537e23789a.jpg', 1, 0, '2016-05-21 10:03:30', '0000-00-00 00:00:00'),
(138, 1, 'kixo', 'http://www.kixo.com.au', '', 'kixo', '<p>kixo</p>', '32dc25fe0ebe6b51aa1a8efb50a17b16.jpg', '183dc2d3421430789b2866bc95a200e6.jpg', 1, 0, '2016-05-21 10:04:25', '0000-00-00 00:00:00');
INSERT INTO `portfolios` (`id`, `category_id`, `title`, `link`, `logo`, `short_description`, `description`, `small_img`, `big_img`, `status`, `show_home`, `added_on`, `updated_on`) VALUES
(139, 1, 'Lisafarleydesigns', 'http://www.lisafarleydesigns.com.au', '', 'Lisafarleydesigns', '<p>Lisafarleydesigns</p>', 'b3600935de2f410168b94b292fbdadf2.jpg', 'f731ec4f0b0e4efe8d2b2f2366595826.jpg', 1, 0, '2016-05-21 10:06:01', '2016-05-23 09:19:03');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `icon`) VALUES
(1, 'Branding', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation.', 'fa fa-bullhorn'),
(2, 'Game Design', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation.', 'fa fa-caret-square-o-up'),
(3, 'Development', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation.', 'fa fa-keyboard-o'),
(4, 'Online Marketing', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation.', 'fa fa-pencil'),
(5, 'Business Template', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation.', 'fa fa-pencil'),
(6, 'Designing', 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation.', 'fa fa-keyboard-o');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE IF NOT EXISTS `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `image` varchar(256) NOT NULL,
  `position` varchar(256) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `image`, `position`, `description`) VALUES
(1, 'Pushpendra Rajput', '', 'Software Developer', 'description'),
(2, 'Kapil Rai', '', 'Software Tester', 'description'),
(3, 'Ramnaresh Rajput', '', 'Application Developer', 'description'),
(4, 'Avinash Yadav', '', 'PHP Developer', 'description');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `user_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `user_role_id` int(11) NOT NULL DEFAULT '4',
  `address` varchar(500) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(500) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `user_description` text,
  `user_added_date` datetime DEFAULT NULL,
  `user_modified_date` datetime DEFAULT NULL,
  `last_login_date` datetime DEFAULT NULL,
  `last_login_ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`, `first_name`, `last_name`, `user_status`, `user_role_id`, `address`, `phone`, `city`, `state`, `country_id`, `zip_code`, `user_description`, `user_added_date`, `user_modified_date`, `last_login_date`, `last_login_ip`) VALUES
(1, 'admin@admin.com', 'ee7a3105d05807ef12cda91e54048dbdc7a8b65f', 'pksingh', 'pksingh', 'Active', 1, 'noida', '9990041445', 'noida', '5', 110, '110091', 'hi this is demo', NULL, '2013-04-24 14:00:38', '2014-02-15 16:25:29', '::1'),
(2, 'subadmin@subadmin.com', 'ee7a3105d05807ef12cda91e54048dbdc7a8b65f', 'Pappu Singh', 'Singh', 'Active', 2, 'Noida', '99900411445', 'Noida', 'Delhi', 110, '11092', 'Administrator', NULL, '2014-01-16 13:32:11', '2014-01-16 10:00:30', '::1'),
(3, 'author@author.com', 'ee7a3105d05807ef12cda91e54048dbdc7a8b65f', 'Author', 'Author', 'Active', 3, 'noida', '99900411445', 'noida', '1', 1, '11092', 'demo', '2013-04-24 18:39:23', '2014-01-16 13:45:50', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE IF NOT EXISTS `user_roles` (
  `user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_name` varchar(255) NOT NULL,
  `user_role_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `user_role_description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`user_role_id`, `user_role_name`, `user_role_status`, `user_role_description`) VALUES
(1, 'Admin', 'Active', 'Super Admin'),
(2, 'Sub Admin', 'Active', 'Sub Admin'),
(3, 'Auther', 'Active', 'users');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
